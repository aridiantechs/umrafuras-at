--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = websites, pg_catalog;

ALTER TABLE ONLY websites.stats DROP CONSTRAINT stats_pkey;
ALTER TABLE ONLY websites."Domains" DROP CONSTRAINT domains_pkey;
ALTER TABLE ONLY websites.contents DROP CONSTRAINT contents_pkey;
ALTER TABLE ONLY websites.contents_meta DROP CONSTRAINT contents_meta_pkey;
ALTER TABLE ONLY websites."Settings" DROP CONSTRAINT "Settings_Key_DomainID";
ALTER TABLE ONLY websites."Search" DROP CONSTRAINT "Search_pkey";
ALTER TABLE ONLY websites."Orders" DROP CONSTRAINT "Orders_pkey";
ALTER TABLE ONLY websites."Orders_Ziyarat" DROP CONSTRAINT "Orders_Ziyarat_pkey";
ALTER TABLE ONLY websites."Orders_Transport" DROP CONSTRAINT "Orders_Transport_pkey";
ALTER TABLE ONLY websites."Orders_Hotel" DROP CONSTRAINT "Orders_Hotel_pkey";
ALTER TABLE ONLY websites."Orders_Flights" DROP CONSTRAINT "Orders_Flights_pkey";
ALTER TABLE ONLY websites."Order_Payment" DROP CONSTRAINT "Order_Payment_pkey";
ALTER TABLE ONLY websites."Flight_Sectors" DROP CONSTRAINT "Flight_Sectors_pkey";
SET search_path = voucher, pg_catalog;

ALTER TABLE ONLY voucher."ZiyaratsRate" DROP CONSTRAINT "ZiyaratsRate_pkey";
ALTER TABLE ONLY voucher."TransportRate" DROP CONSTRAINT "TransportRate_pkey";
ALTER TABLE ONLY voucher."Services" DROP CONSTRAINT "Services_pkey";
ALTER TABLE ONLY voucher."Remarks" DROP CONSTRAINT "Remarks_pkey";
ALTER TABLE ONLY voucher."Pilgrim" DROP CONSTRAINT "Pilgrim_pkey";
ALTER TABLE ONLY voucher."Master" DROP CONSTRAINT "Master_pkey";
ALTER TABLE ONLY voucher."Flights" DROP CONSTRAINT "Flights_pkey";
ALTER TABLE ONLY voucher."AccommodationDetails" DROP CONSTRAINT "AccommodationDetails_pkey";
SET search_path = uploads, pg_catalog;

ALTER TABLE ONLY uploads."Files" DROP CONSTRAINT "Files_pkey";
SET search_path = temp, pg_catalog;

ALTER TABLE ONLY temp.mofa_file DROP CONSTRAINT mofa_file_pkey;
ALTER TABLE ONLY temp.mofa_file DROP CONSTRAINT "mofaID";
ALTER TABLE ONLY temp.elm_file DROP CONSTRAINT elm_file_pkey;
ALTER TABLE ONLY temp.elm_file DROP CONSTRAINT "Passport";
SET search_path = sale_agent, pg_catalog;

ALTER TABLE ONLY sale_agent."Meta" DROP CONSTRAINT "Meta_pkey";
ALTER TABLE ONLY sale_agent."Agents" DROP CONSTRAINT "Agents_pkey";
SET search_path = pilgrim, pg_catalog;

ALTER TABLE ONLY pilgrim.visa DROP CONSTRAINT visa_pkey;
ALTER TABLE ONLY pilgrim.travel DROP CONSTRAINT travel_pkey;
ALTER TABLE ONLY pilgrim.passport DROP CONSTRAINT passport_pkey;
ALTER TABLE ONLY pilgrim.meta DROP CONSTRAINT meta_pkey;
ALTER TABLE ONLY pilgrim.master DROP CONSTRAINT master_pkey;
ALTER TABLE ONLY pilgrim.auth DROP CONSTRAINT auth_pkey;
ALTER TABLE ONLY pilgrim.attachments DROP CONSTRAINT attachments_pkey;
ALTER TABLE ONLY pilgrim.activities DROP CONSTRAINT activities_pkey;
SET search_path = packages, pg_catalog;

ALTER TABLE ONLY packages."Ziyarats" DROP CONSTRAINT "Ziyarats_pkey";
ALTER TABLE ONLY packages."ZiyaratsRate" DROP CONSTRAINT "ZiyaratsRate_pkey";
ALTER TABLE ONLY packages."Transport" DROP CONSTRAINT "Transport_pkey";
ALTER TABLE ONLY packages."TransportRate" DROP CONSTRAINT "TransportRate_pkey";
ALTER TABLE ONLY packages."TransportImage" DROP CONSTRAINT "TransportImage_pkey";
ALTER TABLE ONLY packages."ServiceRate" DROP CONSTRAINT "ServiceRate_pkey";
ALTER TABLE ONLY packages."Packages" DROP CONSTRAINT "Packages_pkey";
ALTER TABLE ONLY packages."OtherHotels" DROP CONSTRAINT "OtherHotels_pkey";
ALTER TABLE ONLY packages."Meta" DROP CONSTRAINT "Meta_pkey";
ALTER TABLE ONLY packages."Hotels" DROP CONSTRAINT "Hotels_pkey";
ALTER TABLE ONLY packages."HotelsRate" DROP CONSTRAINT "HotelsRate_pkey1";
ALTER TABLE ONLY packages."HotelImage" DROP CONSTRAINT "HotelImage_pkey";
SET search_path = main, pg_catalog;

ALTER TABLE ONLY main."Operators" DROP CONSTRAINT operators_pkey;
ALTER TABLE ONLY main."Users" DROP CONSTRAINT "Users_pkey";
ALTER TABLE ONLY main."UsersMeta" DROP CONSTRAINT "UsersMeta_pkey";
ALTER TABLE ONLY main."Lookups" DROP CONSTRAINT "Lookups_pkey";
ALTER TABLE ONLY main."LookupsOptions" DROP CONSTRAINT "LookupsOptions_pkey";
ALTER TABLE ONLY main."Language" DROP CONSTRAINT "Language_pkey";
ALTER TABLE ONLY main."LanguageTranslations" DROP CONSTRAINT "LanguageTranslations_pkey";
ALTER TABLE ONLY main."Lookups" DROP CONSTRAINT "KeyDuplicate";
ALTER TABLE ONLY main."Groups" DROP CONSTRAINT "Groups_pkey";
ALTER TABLE ONLY main."GroupZiyarat" DROP CONSTRAINT "GroupZiyarat_pkey";
ALTER TABLE ONLY main."GroupTransport" DROP CONSTRAINT "GroupTransport_pkey";
ALTER TABLE ONLY main."GroupServices" DROP CONSTRAINT "GroupServices_pkey";
ALTER TABLE ONLY main."GroupHotel" DROP CONSTRAINT "GroupHotel_pkey";
ALTER TABLE ONLY main."ExternalAgent" DROP CONSTRAINT "ExternalAgent_pkey";
ALTER TABLE ONLY main."Countries" DROP CONSTRAINT "Countries_pkey";
ALTER TABLE ONLY main."Countries" DROP CONSTRAINT "Countries_ISO2";
ALTER TABLE ONLY main."LanguageTranslations" DROP CONSTRAINT "Code_Key";
ALTER TABLE ONLY main."Cities" DROP CONSTRAINT "Cities_pkey";
ALTER TABLE ONLY main."Airports" DROP CONSTRAINT "Airports_pkey";
ALTER TABLE ONLY main."Airlines" DROP CONSTRAINT "Airlines_pkey";
ALTER TABLE ONLY main."Agents" DROP CONSTRAINT "Agents_pkey";
ALTER TABLE ONLY main."AgentFiles" DROP CONSTRAINT "AgentImages_pkey";
ALTER TABLE ONLY main."AdminSettings" DROP CONSTRAINT "AdminSettings_Key_DomainID";
ALTER TABLE ONLY main."AdminLog" DROP CONSTRAINT "AdminLog_pkey";
ALTER TABLE ONLY main."AccessLevel" DROP CONSTRAINT "AccessLevel_pkey";
SET search_path = "BRN", pg_catalog;

ALTER TABLE ONLY "BRN".brn DROP CONSTRAINT brn_pkey;
ALTER TABLE ONLY "BRN"."UseBRN" DROP CONSTRAINT "UseBRN_pkey";
SET search_path = websites, pg_catalog;

SET search_path = voucher, pg_catalog;

SET search_path = uploads, pg_catalog;

SET search_path = temp, pg_catalog;

SET search_path = sale_agent, pg_catalog;

SET search_path = pilgrim, pg_catalog;

SET search_path = packages, pg_catalog;

SET search_path = main, pg_catalog;

SET search_path = "BRN", pg_catalog;

SET search_path = websites, pg_catalog;

DROP TABLE websites.stats;
DROP SEQUENCE websites."stats_UID_seq";
DROP TABLE websites.contents_meta;
DROP SEQUENCE websites."contents_meta_UID_seq";
DROP TABLE websites.contents;
DROP SEQUENCE websites."contents_UID_seq";
DROP TABLE websites."Settings";
DROP TABLE websites."Search";
DROP SEQUENCE websites."Search_UID_seq";
DROP TABLE websites."Orders_Ziyarat";
DROP SEQUENCE websites."Orders_Ziyarat_UID_seq";
DROP TABLE websites."Orders_Transport";
DROP SEQUENCE websites."Orders_Transport_UID_seq";
DROP TABLE websites."Orders_Hotel";
DROP SEQUENCE websites."Orders_Hotel_UID_seq";
DROP TABLE websites."Orders_Flights";
DROP SEQUENCE websites."Orders_Flights_UID_seq";
DROP TABLE websites."Orders";
DROP SEQUENCE websites."Orders_UID_seq";
DROP TABLE websites."Order_Payment";
DROP SEQUENCE websites."Order_Payment_UID_seq";
DROP TABLE websites."Flight_Sectors";
DROP SEQUENCE websites."Flight_Sectors_UID_seq";
DROP TABLE websites."Domains";
DROP SEQUENCE websites."domains_UID_seq";
SET search_path = voucher, pg_catalog;

DROP TABLE voucher."ZiyaratsRate";
DROP SEQUENCE voucher."ZiyaratsRate_UID_seq";
DROP TABLE voucher."TransportRate";
DROP SEQUENCE voucher."TransportRate_UID_seq";
DROP TABLE voucher."Services";
DROP SEQUENCE voucher."Services_UID_seq";
DROP TABLE voucher."Remarks";
DROP SEQUENCE voucher."Remarks_UID_seq";
DROP TABLE voucher."Pilgrim";
DROP SEQUENCE voucher."Pilgrim_UID_seq";
DROP TABLE voucher."Master";
DROP SEQUENCE voucher."Master_UID_seq";
DROP TABLE voucher."Flights";
DROP SEQUENCE voucher."Flights_UID_seq";
DROP TABLE voucher."AccommodationDetails";
DROP SEQUENCE voucher."AccommodationDetails_UID_seq";
SET search_path = uploads, pg_catalog;

DROP TABLE uploads."Files";
DROP SEQUENCE uploads."Files_UID_seq";
SET search_path = temp, pg_catalog;

DROP TABLE temp.mofa_file;
DROP SEQUENCE temp."mofa_file_UID_seq";
DROP TABLE temp.elm_file;
DROP SEQUENCE temp."elm_file_UID_seq";
SET search_path = sale_agent, pg_catalog;

DROP TABLE sale_agent."Meta";
DROP SEQUENCE sale_agent."Meta_UID_seq";
DROP TABLE sale_agent."Agents";
DROP SEQUENCE sale_agent."Agents_UID_seq";
SET search_path = pilgrim, pg_catalog;

DROP TABLE pilgrim.visa;
DROP TABLE pilgrim.travel;
DROP SEQUENCE pilgrim."travel_UID_seq";
DROP TABLE pilgrim.passport;
DROP SEQUENCE pilgrim."passport_UID_seq";
DROP TABLE pilgrim.mofa;
DROP TABLE pilgrim.meta;
DROP SEQUENCE pilgrim."meta_UID_seq";
DROP TABLE pilgrim.master;
DROP SEQUENCE pilgrim."master_UID_seq";
DROP TABLE pilgrim.auth;
DROP SEQUENCE pilgrim."auth_UID_seq";
DROP TABLE pilgrim.attachments;
DROP SEQUENCE pilgrim."attachments_UID_seq";
DROP TABLE pilgrim.activities;
DROP SEQUENCE pilgrim."activities_UID_seq";
SET search_path = packages, pg_catalog;

DROP TABLE packages."ZiyaratsRate";
DROP SEQUENCE packages."ZiyaratsRate_UID_seq";
DROP TABLE packages."Ziyarats";
DROP SEQUENCE packages."Ziyarats_UID_seq";
DROP TABLE packages."TransportRate";
DROP SEQUENCE packages."TransportRate_UID_seq";
DROP TABLE packages."TransportImage";
DROP SEQUENCE packages."TransportImage_UID_seq";
DROP TABLE packages."Transport";
DROP SEQUENCE packages."Transport_UID_seq";
DROP TABLE packages."ServiceRate";
DROP SEQUENCE packages."ServiceRate_UID_seq";
DROP TABLE packages."Packages";
DROP SEQUENCE packages."Packages_UID_seq";
DROP TABLE packages."OtherHotels";
DROP SEQUENCE packages."OtherHotels_UID_seq";
DROP TABLE packages."Meta";
DROP SEQUENCE packages."Meta_UID_seq";
DROP TABLE packages."HotelsRate";
DROP SEQUENCE packages."HotelsRate_UID_seq";
DROP TABLE packages."Hotels";
DROP SEQUENCE packages."Hotels_UID_seq";
DROP TABLE packages."HotelImage";
DROP SEQUENCE packages."HotelImage_UID_seq";
SET search_path = main, pg_catalog;

DROP TABLE main."UsersMeta";
DROP SEQUENCE main."UsersMeta_UID_seq";
DROP TABLE main."Users";
DROP SEQUENCE main."Users_UID_seq";
DROP TABLE main."Operators";
DROP SEQUENCE main."operators_UID_seq";
DROP TABLE main."LookupsOptions";
DROP SEQUENCE main."LookupsOptions_UID_seq";
DROP TABLE main."Lookups";
DROP SEQUENCE main."Lookups_UID_seq";
DROP TABLE main."LanguageTranslations";
DROP SEQUENCE main."LanguageTranslations_UID_seq";
DROP TABLE main."Language";
DROP SEQUENCE main."Language_UID_seq";
DROP TABLE main."Groups";
DROP SEQUENCE main."Groups_UID_seq";
DROP TABLE main."GroupZiyarat";
DROP SEQUENCE main."GroupZiyarat_UID_seq";
DROP TABLE main."GroupTransport";
DROP SEQUENCE main."GroupTransport_UID_seq";
DROP TABLE main."GroupServices";
DROP SEQUENCE main."GroupServices_UID_seq";
DROP TABLE main."GroupHotel";
DROP SEQUENCE main."GroupHotel_UID_seq";
DROP TABLE main."ExternalAgent";
DROP SEQUENCE main."ExternalAgent_UID_seq";
DROP TABLE main."Countries";
DROP SEQUENCE main."Countries_UID_seq";
DROP TABLE main."Cities";
DROP SEQUENCE main."Cities_UID_seq";
DROP TABLE main."Airports";
DROP SEQUENCE main."Airports_UID_seq";
DROP TABLE main."Airlines";
DROP SEQUENCE main."Airlines_UID_seq";
DROP TABLE main."Agents";
DROP SEQUENCE main."Agents_UID_seq";
DROP TABLE main."AgentFiles";
DROP SEQUENCE main."AgentFiles_UID_seq";
DROP TABLE main."AdminSettings";
DROP TABLE main."AdminLog";
DROP SEQUENCE main."AdminLog_UID_seq";
DROP TABLE main."AccessLevel";
DROP SEQUENCE main."AccessLevel_UID_seq";
SET search_path = "BRN", pg_catalog;

DROP TABLE "BRN".brn;
DROP SEQUENCE "BRN"."brn_UID_seq";
DROP TABLE "BRN"."UseBRN";
DROP SEQUENCE "BRN"."UseBRN_UID_seq";
DROP EXTENSION plpgsql;
DROP SCHEMA websites;
DROP SCHEMA voucher;
DROP SCHEMA uploads;
DROP SCHEMA temp;
DROP SCHEMA sale_agent;
DROP SCHEMA public;
DROP SCHEMA pilgrim;
DROP SCHEMA packages;
DROP SCHEMA main;
DROP SCHEMA "BRN";
--
-- Name: BRN; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "BRN";


ALTER SCHEMA "BRN" OWNER TO postgres;

--
-- Name: main; Type: SCHEMA; Schema: -; Owner: umrahfuras
--

CREATE SCHEMA main;


ALTER SCHEMA main OWNER TO umrahfuras;

--
-- Name: packages; Type: SCHEMA; Schema: -; Owner: umrahfuras
--

CREATE SCHEMA packages;


ALTER SCHEMA packages OWNER TO umrahfuras;

--
-- Name: pilgrim; Type: SCHEMA; Schema: -; Owner: umrahfuras
--

CREATE SCHEMA pilgrim;


ALTER SCHEMA pilgrim OWNER TO umrahfuras;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: umrahfuras
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO umrahfuras;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: umrahfuras
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: sale_agent; Type: SCHEMA; Schema: -; Owner: umrahfuras
--

CREATE SCHEMA sale_agent;


ALTER SCHEMA sale_agent OWNER TO umrahfuras;

--
-- Name: temp; Type: SCHEMA; Schema: -; Owner: umrahfuras
--

CREATE SCHEMA temp;


ALTER SCHEMA temp OWNER TO umrahfuras;

--
-- Name: uploads; Type: SCHEMA; Schema: -; Owner: umrahfuras
--

CREATE SCHEMA uploads;


ALTER SCHEMA uploads OWNER TO umrahfuras;

--
-- Name: voucher; Type: SCHEMA; Schema: -; Owner: umrahfuras
--

CREATE SCHEMA voucher;


ALTER SCHEMA voucher OWNER TO umrahfuras;

--
-- Name: websites; Type: SCHEMA; Schema: -; Owner: umrahfuras
--

CREATE SCHEMA websites;


ALTER SCHEMA websites OWNER TO umrahfuras;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = "BRN", pg_catalog;

--
-- Name: UseBRN_UID_seq; Type: SEQUENCE; Schema: BRN; Owner: umrahfuras
--

CREATE SEQUENCE "UseBRN_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "BRN"."UseBRN_UID_seq" OWNER TO umrahfuras;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: UseBRN; Type: TABLE; Schema: BRN; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "UseBRN" (
    "UID" bigint DEFAULT nextval('"UseBRN_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Type" text,
    "BRNCode" character varying,
    "Rooms" bigint DEFAULT 0::bigint,
    "Beds" bigint DEFAULT 0::bigint,
    "UseID" bigint,
    "UsedDate" date,
    "Seats" bigint,
    "Archive" integer DEFAULT 0
);


ALTER TABLE "BRN"."UseBRN" OWNER TO umrahfuras;

--
-- Name: brn_UID_seq; Type: SEQUENCE; Schema: BRN; Owner: umrahfuras
--

CREATE SEQUENCE "brn_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "BRN"."brn_UID_seq" OWNER TO umrahfuras;

--
-- Name: brn; Type: TABLE; Schema: BRN; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE brn (
    "UID" bigint DEFAULT nextval('"brn_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "BRNCode" text,
    "Operator" text,
    "Company" text,
    "Seats" text,
    "Beds" text,
    "Rooms" text,
    "GenerateDate" date,
    "ActiveDate" date,
    "ExpireDate" date,
    "WebsiteDomain" bigint,
    "Archive" smallint DEFAULT 0::smallint,
    "HotelsID" bigint,
    "BRNType" text,
    "CreatedBy" bigint,
    "CreatedDate" date,
    "ModifiedBy" bigint,
    "ModifiedDate" date,
    "PurchaseID" character varying,
    "PurchasedBy" integer,
    "NoOfVehicles" integer,
    "UseType" character varying,
    "BookingDate" date,
    "TransportType" integer
);


ALTER TABLE "BRN".brn OWNER TO umrahfuras;

SET search_path = main, pg_catalog;

--
-- Name: AccessLevel_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "AccessLevel_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE main."AccessLevel_UID_seq" OWNER TO umrahfuras;

--
-- Name: AccessLevel; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "AccessLevel" (
    "UID" integer DEFAULT nextval('"AccessLevel_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now() NOT NULL,
    "UserID" integer NOT NULL,
    "AccessKey" character varying(256) NOT NULL,
    "Access" integer NOT NULL
);


ALTER TABLE main."AccessLevel" OWNER TO umrahfuras;

--
-- Name: AdminLog_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "AdminLog_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."AdminLog_UID_seq" OWNER TO umrahfuras;

--
-- Name: AdminLog; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "AdminLog" (
    "UID" bigint DEFAULT nextval('"AdminLog_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "LogSegment" character varying(255),
    "LogNotes" text,
    "LogIP" character varying(50)
);


ALTER TABLE main."AdminLog" OWNER TO umrahfuras;

--
-- Name: AdminSettings; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "AdminSettings" (
    "Key" character varying(255),
    "Name" character varying(255),
    "Segment" character varying(255),
    "Description" text,
    "OrderNo" integer DEFAULT 0,
    "DomainID" bigint DEFAULT 0::bigint
);


ALTER TABLE main."AdminSettings" OWNER TO umrahfuras;

--
-- Name: AgentFiles_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "AgentFiles_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."AgentFiles_UID_seq" OWNER TO umrahfuras;

--
-- Name: AgentFiles; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "AgentFiles" (
    "UID" bigint DEFAULT nextval('"AgentFiles_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "AgentID" character varying,
    "FileDescription" character varying,
    "FileID" character varying
);


ALTER TABLE main."AgentFiles" OWNER TO umrahfuras;

--
-- Name: Agents_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "Agents_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."Agents_UID_seq" OWNER TO umrahfuras;

--
-- Name: Agents; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Agents" (
    "UID" bigint DEFAULT nextval('"Agents_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "FullName" text,
    "PhoneNumber" character varying,
    "Email" character varying,
    "Password" character varying,
    "Address" character varying,
    "Archive" bigint DEFAULT 0 NOT NULL,
    "ParentID" bigint DEFAULT 0::bigint NOT NULL,
    "FaxNumber" character varying,
    "MobileNumber" character varying,
    "CityID" character varying,
    "CountryID" character varying,
    "ContactPersonName" text,
    "SalesmanID" bigint DEFAULT 0::bigint NOT NULL,
    "SalesmanName" bigint DEFAULT 0::bigint NOT NULL,
    "Status" text,
    "Logo" text,
    "IATALicense" character varying,
    "UmrahAgreement" character varying,
    "CompanyName" character varying,
    "WebsiteDomain" bigint DEFAULT 0::bigint,
    "Type" character varying,
    "LastName" text,
    "Domain" text
);


ALTER TABLE main."Agents" OWNER TO umrahfuras;

--
-- Name: Airlines_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "Airlines_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."Airlines_UID_seq" OWNER TO umrahfuras;

--
-- Name: Airlines; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Airlines" (
    "UID" bigint DEFAULT nextval('"Airlines_UID_seq"'::regclass) NOT NULL,
    "Code" character varying(10),
    "FullName" character varying(500),
    "CountryISO2" character varying(500),
    "Status" character varying(5),
    "Archive" smallint DEFAULT 0
);


ALTER TABLE main."Airlines" OWNER TO umrahfuras;

--
-- Name: Airports_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "Airports_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."Airports_UID_seq" OWNER TO umrahfuras;

--
-- Name: Airports; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Airports" (
    "UID" bigint DEFAULT nextval('"Airports_UID_seq"'::regclass) NOT NULL,
    "Name" character varying(150),
    "Code" character varying(10),
    "StateCode" character varying(50),
    "CountryCode" character varying(50),
    "CountryName" character varying(100)
);


ALTER TABLE main."Airports" OWNER TO umrahfuras;

--
-- Name: Cities_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "Cities_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."Cities_UID_seq" OWNER TO umrahfuras;

--
-- Name: Cities; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Cities" (
    "UID" bigint DEFAULT nextval('"Cities_UID_seq"'::regclass) NOT NULL,
    "Name" character varying(150),
    "StateUID" bigint,
    "StateCode" character varying(50),
    "CountryUID" bigint,
    "CountryCode" character varying(50),
    "Latitude" double precision,
    "Longitude" double precision,
    "Slug" character varying,
    "CoverImage" bigint DEFAULT 0::bigint NOT NULL
);


ALTER TABLE main."Cities" OWNER TO umrahfuras;

--
-- Name: Countries_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "Countries_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."Countries_UID_seq" OWNER TO umrahfuras;

--
-- Name: Countries; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Countries" (
    "UID" bigint DEFAULT nextval('"Countries_UID_seq"'::regclass) NOT NULL,
    "Name" character varying(150),
    "ISO2" character varying(50),
    "ISO3" character varying,
    "PhoneCode" character varying(50),
    "Capital" character varying(50),
    "Currency" character varying(50)
);


ALTER TABLE main."Countries" OWNER TO umrahfuras;

--
-- Name: ExternalAgent_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "ExternalAgent_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."ExternalAgent_UID_seq" OWNER TO umrahfuras;

--
-- Name: ExternalAgent; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "ExternalAgent" (
    "UID" bigint DEFAULT nextval('"ExternalAgent_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "FullName" character varying,
    "Archive" smallint DEFAULT 0,
    "DomainID" bigint DEFAULT 0::bigint
);


ALTER TABLE main."ExternalAgent" OWNER TO umrahfuras;

--
-- Name: GroupHotel_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "GroupHotel_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."GroupHotel_UID_seq" OWNER TO umrahfuras;

--
-- Name: GroupHotel; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "GroupHotel" (
    "UID" bigint DEFAULT nextval('"GroupHotel_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "GroupID" bigint,
    "City" character varying,
    "Hotel" bigint,
    "RoomType" bigint,
    "CheckIn" date,
    "CheckOut" date,
    "NoOfBeds" bigint,
    "AmountPayable" bigint
);


ALTER TABLE main."GroupHotel" OWNER TO umrahfuras;

--
-- Name: GroupServices_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "GroupServices_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."GroupServices_UID_seq" OWNER TO umrahfuras;

--
-- Name: GroupServices; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "GroupServices" (
    "UID" bigint DEFAULT nextval('"GroupServices_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "GroupID" bigint,
    "ServiceID" bigint,
    "ServiceRate" bigint
);


ALTER TABLE main."GroupServices" OWNER TO umrahfuras;

--
-- Name: GroupTransport_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "GroupTransport_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."GroupTransport_UID_seq" OWNER TO umrahfuras;

--
-- Name: GroupTransport; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "GroupTransport" (
    "UID" bigint DEFAULT nextval('"GroupTransport_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "GroupID" bigint,
    "TransportSectors" bigint,
    "Transport" bigint,
    "NoOfPax" bigint,
    "NoOfSeats" bigint,
    "TransportsRates" bigint
);


ALTER TABLE main."GroupTransport" OWNER TO umrahfuras;

--
-- Name: GroupZiyarat_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "GroupZiyarat_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."GroupZiyarat_UID_seq" OWNER TO umrahfuras;

--
-- Name: GroupZiyarat; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "GroupZiyarat" (
    "UID" bigint DEFAULT nextval('"GroupZiyarat_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "GroupID" bigint,
    "ZiyaratCity" bigint,
    "Ziyarat" bigint,
    "TransportRateZiyrat" bigint,
    "ZiyaratTransport" bigint,
    "ZiyaratNoOfPax" bigint
);


ALTER TABLE main."GroupZiyarat" OWNER TO umrahfuras;

--
-- Name: Groups_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "Groups_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."Groups_UID_seq" OWNER TO umrahfuras;

--
-- Name: Groups; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Groups" (
    "UID" bigint DEFAULT nextval('"Groups_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "FullName" text,
    "Archive" bigint DEFAULT 0,
    "AgentID" bigint,
    "WebsiteDomain" bigint,
    "Country" character varying(150),
    "WTUCode" character varying(150),
    "NoOfPAX" bigint,
    "TransportType" character varying(150),
    "ArrivalDate" date,
    "DepartureDate" date,
    "Remarks" text,
    "Status" character varying DEFAULT 'in-complete'::character varying,
    "Visa" bigint
);


ALTER TABLE main."Groups" OWNER TO umrahfuras;

--
-- Name: Language_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "Language_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."Language_UID_seq" OWNER TO umrahfuras;

--
-- Name: Language; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Language" (
    "UID" bigint DEFAULT nextval('"Language_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Name" text,
    "Code" character varying,
    "DefaultFlag" smallint DEFAULT 0::smallint NOT NULL,
    "RTL" smallint DEFAULT 0::smallint NOT NULL
);


ALTER TABLE main."Language" OWNER TO umrahfuras;

--
-- Name: LanguageTranslations_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "LanguageTranslations_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."LanguageTranslations_UID_seq" OWNER TO umrahfuras;

--
-- Name: LanguageTranslations; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "LanguageTranslations" (
    "UID" bigint DEFAULT nextval('"LanguageTranslations_UID_seq"'::regclass) NOT NULL,
    "Code" character varying(10),
    "Key" character varying(500),
    "Value" text
);


ALTER TABLE main."LanguageTranslations" OWNER TO umrahfuras;

--
-- Name: Lookups_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "Lookups_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."Lookups_UID_seq" OWNER TO umrahfuras;

--
-- Name: Lookups; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Lookups" (
    "UID" bigint DEFAULT nextval('"Lookups_UID_seq"'::regclass) NOT NULL,
    "Key" character varying(150),
    "Name" character varying(150),
    "Description" text
);


ALTER TABLE main."Lookups" OWNER TO umrahfuras;

--
-- Name: LookupsOptions_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "LookupsOptions_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."LookupsOptions_UID_seq" OWNER TO umrahfuras;

--
-- Name: LookupsOptions; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "LookupsOptions" (
    "UID" bigint DEFAULT nextval('"LookupsOptions_UID_seq"'::regclass) NOT NULL,
    "LookupID" bigint,
    "Name" text,
    "OrderID" bigint,
    "Archive" smallint DEFAULT 0::smallint
);


ALTER TABLE main."LookupsOptions" OWNER TO umrahfuras;

--
-- Name: operators_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "operators_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."operators_UID_seq" OWNER TO umrahfuras;

--
-- Name: Operators; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Operators" (
    "UID" bigint DEFAULT nextval('"operators_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "CompanyName" text,
    "Archive" bigint DEFAULT 0,
    "WebsiteDomain" bigint,
    "ContactPersonName" text,
    "ContactNo" character varying(150),
    "Email" character varying(150),
    "OfficeCity" text,
    "Category" text,
    "Country" character varying(150),
    "Type" character varying(150),
    "Logo" integer
);


ALTER TABLE main."Operators" OWNER TO umrahfuras;

--
-- Name: Users_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "Users_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."Users_UID_seq" OWNER TO umrahfuras;

--
-- Name: Users; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Users" (
    "UID" bigint DEFAULT nextval('"Users_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "FullName" text,
    "ContactNumber" character varying,
    "Email" character varying,
    "Password" character varying,
    "Designation" text,
    "UserType" character varying,
    "Archive" bigint DEFAULT 0 NOT NULL,
    "AgentID" bigint,
    "DomainID" bigint DEFAULT 0::bigint
);


ALTER TABLE main."Users" OWNER TO umrahfuras;

--
-- Name: UsersMeta_UID_seq; Type: SEQUENCE; Schema: main; Owner: umrahfuras
--

CREATE SEQUENCE "UsersMeta_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE main."UsersMeta_UID_seq" OWNER TO umrahfuras;

--
-- Name: UsersMeta; Type: TABLE; Schema: main; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "UsersMeta" (
    "UID" bigint DEFAULT nextval('"UsersMeta_UID_seq"'::regclass) NOT NULL,
    "UserUID" character varying,
    "Option" character varying(250),
    "Value" text
);


ALTER TABLE main."UsersMeta" OWNER TO umrahfuras;

SET search_path = packages, pg_catalog;

--
-- Name: HotelImage_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "HotelImage_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."HotelImage_UID_seq" OWNER TO umrahfuras;

--
-- Name: HotelImage; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "HotelImage" (
    "UID" bigint DEFAULT nextval('"HotelImage_UID_seq"'::regclass) NOT NULL,
    "HotelID" bigint,
    "ImageID" bigint
);


ALTER TABLE packages."HotelImage" OWNER TO umrahfuras;

--
-- Name: Hotels_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "Hotels_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."Hotels_UID_seq" OWNER TO umrahfuras;

--
-- Name: Hotels; Type: TABLE; Schema: packages; Owner: postgres; Tablespace: 
--

CREATE TABLE "Hotels" (
    "UID" bigint DEFAULT nextval('"Hotels_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Name" character varying,
    "Category" character varying,
    "Distance" character varying,
    "Address" character varying,
    "TelephoneNumber" character varying,
    "Latitude" character varying,
    "Longitude" character varying,
    "GoogleMAP" character varying,
    "Archive" smallint DEFAULT 0::smallint,
    "CountryID" character varying,
    "CityID" bigint,
    "Description" character varying,
    "Status" character varying,
    "WebsiteDomain" bigint
);


ALTER TABLE packages."Hotels" OWNER TO postgres;

--
-- Name: HotelsRate_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "HotelsRate_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."HotelsRate_UID_seq" OWNER TO umrahfuras;

--
-- Name: HotelsRate; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "HotelsRate" (
    "UID" bigint DEFAULT nextval('"HotelsRate_UID_seq"'::regclass) NOT NULL,
    "PackageUID" bigint,
    "HotelUID" bigint,
    "RoomTypeUID" bigint,
    "Rate" double precision,
    "RowID" smallint
);


ALTER TABLE packages."HotelsRate" OWNER TO umrahfuras;

--
-- Name: Meta_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "Meta_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."Meta_UID_seq" OWNER TO umrahfuras;

--
-- Name: Meta; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Meta" (
    "UID" bigint DEFAULT nextval('"Meta_UID_seq"'::regclass) NOT NULL,
    "ReferenceID" character varying,
    "ReferenceType" character varying,
    "Option" character varying,
    "Value" character varying
);


ALTER TABLE packages."Meta" OWNER TO umrahfuras;

--
-- Name: OtherHotels_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "OtherHotels_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."OtherHotels_UID_seq" OWNER TO umrahfuras;

--
-- Name: OtherHotels; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "OtherHotels" (
    "UID" bigint DEFAULT nextval('"OtherHotels_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Name" character varying,
    "Category" character varying,
    "Distance" character varying,
    "Address" character varying,
    "TelephoneNumber" character varying,
    "Latitude" character varying,
    "Longitude" character varying,
    "GoogleMAP" character varying,
    "Archive" smallint DEFAULT (0)::smallint,
    "CountryID" character varying,
    "CityID" bigint,
    "Description" character varying,
    "Status" character varying,
    "WebsiteDomain" bigint
);


ALTER TABLE packages."OtherHotels" OWNER TO umrahfuras;

--
-- Name: Packages_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "Packages_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."Packages_UID_seq" OWNER TO umrahfuras;

--
-- Name: Packages; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Packages" (
    "UID" bigint DEFAULT nextval('"Packages_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Name" character varying(500),
    "StartDate" date,
    "ExpireDate" date,
    "Fee" double precision,
    "Archive" smallint DEFAULT 0,
    "CountryCode" character varying,
    "PackageType" character varying,
    "AgentUID" smallint DEFAULT 0::smallint,
    "ApprovalDate" date,
    "WebsiteDomain" bigint
);


ALTER TABLE packages."Packages" OWNER TO umrahfuras;

--
-- Name: ServiceRate_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "ServiceRate_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."ServiceRate_UID_seq" OWNER TO umrahfuras;

--
-- Name: ServiceRate; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "ServiceRate" (
    "UID" bigint DEFAULT nextval('"ServiceRate_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "PackageUID" bigint,
    "ServiceUID" bigint,
    "Rate" double precision
);


ALTER TABLE packages."ServiceRate" OWNER TO umrahfuras;

--
-- Name: Transport_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "Transport_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."Transport_UID_seq" OWNER TO umrahfuras;

--
-- Name: Transport; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Transport" (
    "UID" bigint DEFAULT nextval('"Transport_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Type" character varying,
    "LuggageCapacity" character varying,
    "Description" text,
    "Archive" smallint DEFAULT 0::smallint NOT NULL,
    "PAXDetail" character varying,
    "CoverImage" text,
    "WebsiteDomain" bigint
);


ALTER TABLE packages."Transport" OWNER TO umrahfuras;

--
-- Name: TransportImage_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "TransportImage_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."TransportImage_UID_seq" OWNER TO umrahfuras;

--
-- Name: TransportImage; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "TransportImage" (
    "UID" bigint DEFAULT nextval('"TransportImage_UID_seq"'::regclass) NOT NULL,
    "TransportID" bigint,
    "FileID" bigint
);


ALTER TABLE packages."TransportImage" OWNER TO umrahfuras;

--
-- Name: TransportRate_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "TransportRate_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."TransportRate_UID_seq" OWNER TO umrahfuras;

--
-- Name: TransportRate; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "TransportRate" (
    "UID" bigint DEFAULT nextval('"TransportRate_UID_seq"'::regclass) NOT NULL,
    "PackageUID" bigint,
    "TransportTypeUID" bigint,
    "Rate" double precision,
    "RowID" smallint,
    "Routes" bigint
);


ALTER TABLE packages."TransportRate" OWNER TO umrahfuras;

--
-- Name: Ziyarats_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "Ziyarats_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."Ziyarats_UID_seq" OWNER TO umrahfuras;

--
-- Name: Ziyarats; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Ziyarats" (
    "UID" bigint DEFAULT nextval('"Ziyarats_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Name" text,
    "CountryID" character varying,
    "CityID" bigint,
    "CoverImage" text DEFAULT '0'::text,
    "Description" character varying,
    "NearPlaces" character varying,
    "Archive" smallint DEFAULT 0,
    "WebsiteDomain" bigint
);


ALTER TABLE packages."Ziyarats" OWNER TO umrahfuras;

--
-- Name: ZiyaratsRate_UID_seq; Type: SEQUENCE; Schema: packages; Owner: umrahfuras
--

CREATE SEQUENCE "ZiyaratsRate_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE packages."ZiyaratsRate_UID_seq" OWNER TO umrahfuras;

--
-- Name: ZiyaratsRate; Type: TABLE; Schema: packages; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "ZiyaratsRate" (
    "UID" bigint DEFAULT nextval('"ZiyaratsRate_UID_seq"'::regclass) NOT NULL,
    "PackageUID" bigint,
    "ZiyaratsUID" bigint,
    "Rate" double precision,
    "RowID" smallint,
    "TransportTypeUID" bigint
);


ALTER TABLE packages."ZiyaratsRate" OWNER TO umrahfuras;

SET search_path = pilgrim, pg_catalog;

--
-- Name: activities_UID_seq; Type: SEQUENCE; Schema: pilgrim; Owner: umrahfuras
--

CREATE SEQUENCE "activities_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pilgrim."activities_UID_seq" OWNER TO umrahfuras;

--
-- Name: activities; Type: TABLE; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE activities (
    "UID" bigint DEFAULT nextval('"activities_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "UserID" bigint,
    "PilgrimUID" bigint,
    "Activity" text,
    "ActivityDescription" text,
    "IPAddress" character varying
);


ALTER TABLE pilgrim.activities OWNER TO umrahfuras;

--
-- Name: attachments_UID_seq; Type: SEQUENCE; Schema: pilgrim; Owner: umrahfuras
--

CREATE SEQUENCE "attachments_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pilgrim."attachments_UID_seq" OWNER TO umrahfuras;

--
-- Name: attachments; Type: TABLE; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE attachments (
    "UID" bigint DEFAULT nextval('"attachments_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "PilgrimID" bigint,
    "FileDescription" text,
    "FileID" bigint
);


ALTER TABLE pilgrim.attachments OWNER TO umrahfuras;

--
-- Name: auth_UID_seq; Type: SEQUENCE; Schema: pilgrim; Owner: umrahfuras
--

CREATE SEQUENCE "auth_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pilgrim."auth_UID_seq" OWNER TO umrahfuras;

--
-- Name: auth; Type: TABLE; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE auth (
    "UID" bigint DEFAULT nextval('"auth_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "DomainID" bigint,
    "PilgrimID" bigint,
    "Email" character varying(255),
    "Password" character varying(255),
    "LastLoginDateTime" timestamp without time zone,
    "LastLoginIPAddress" character varying(255),
    "Status" smallint DEFAULT 0::smallint
);


ALTER TABLE pilgrim.auth OWNER TO umrahfuras;

--
-- Name: master_UID_seq; Type: SEQUENCE; Schema: pilgrim; Owner: umrahfuras
--

CREATE SEQUENCE "master_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pilgrim."master_UID_seq" OWNER TO umrahfuras;

--
-- Name: master; Type: TABLE; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE master (
    "UID" bigint DEFAULT nextval('"master_UID_seq"'::regclass) NOT NULL,
    "AgentUID" bigint,
    "GroupUID" bigint,
    "Title" character varying(50),
    "FirstName" character varying(150),
    "LastName" character varying(150),
    "Relation" character varying(150),
    "Profile" text,
    "RegistrationDate" date,
    "Country" character varying,
    "DOB" character varying,
    "DOBInYears" smallint,
    "PassportNumber" character varying(100),
    "Nationality" character varying(100),
    "CurrentStatus" character varying(100) DEFAULT 'new'::character varying,
    "ContactNumber" character varying(200),
    "Email" character varying(250),
    "Password" character varying(200),
    "CityID" character varying(200),
    "ParentID" bigint DEFAULT 0::bigint,
    "WebsiteDomain" bigint DEFAULT 0::bigint,
    "Gender" character varying(15)
);


ALTER TABLE pilgrim.master OWNER TO umrahfuras;

--
-- Name: meta_UID_seq; Type: SEQUENCE; Schema: pilgrim; Owner: umrahfuras
--

CREATE SEQUENCE "meta_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pilgrim."meta_UID_seq" OWNER TO umrahfuras;

--
-- Name: meta; Type: TABLE; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE meta (
    "UID" bigint DEFAULT nextval('"meta_UID_seq"'::regclass) NOT NULL,
    "PilgrimUID" bigint,
    "Option" character varying(100),
    "Value" text,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "CreatedBy" bigint,
    "AllowReference" bigint DEFAULT 0::bigint NOT NULL
);


ALTER TABLE pilgrim.meta OWNER TO umrahfuras;

--
-- Name: mofa; Type: TABLE; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE mofa (
    "MOFANumber" bigint,
    "MOFAPilgrimID" bigint,
    "IssueDateTime" timestamp without time zone,
    "MOINumber" bigint,
    "INSURANCE_POLICY_ID" bigint,
    "PilgrimID" bigint,
    "Embassy" character varying(255)
);


ALTER TABLE pilgrim.mofa OWNER TO umrahfuras;

--
-- Name: passport_UID_seq; Type: SEQUENCE; Schema: pilgrim; Owner: umrahfuras
--

CREATE SEQUENCE "passport_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pilgrim."passport_UID_seq" OWNER TO umrahfuras;

--
-- Name: passport; Type: TABLE; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE passport (
    "UID" bigint DEFAULT nextval('"passport_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "PilgrimID" bigint,
    "PassportNumber" character varying,
    "PassportType" character varying,
    "Nationality" character varying,
    "DateOfIssue" date,
    "DateOfExpiry" date,
    "TrackingNumber" character varying,
    "CitizenshipNumber" character varying,
    "BookletNumber" character varying,
    "File" text
);


ALTER TABLE pilgrim.passport OWNER TO umrahfuras;

--
-- Name: travel_UID_seq; Type: SEQUENCE; Schema: pilgrim; Owner: umrahfuras
--

CREATE SEQUENCE "travel_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pilgrim."travel_UID_seq" OWNER TO umrahfuras;

--
-- Name: travel; Type: TABLE; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE travel (
    "UID" bigint DEFAULT nextval('"travel_UID_seq"'::regclass) NOT NULL,
    "PilgrimID" bigint,
    "MOFAPilgrimID" bigint,
    "PassportNo" text,
    "MOINumber" text,
    "VisaNo" text,
    "EntryDate" date,
    "EntryTime" time without time zone,
    "EntryPort" text,
    "TransportMode" text,
    "EntryCarrier" text,
    "FlightNo" text
);


ALTER TABLE pilgrim.travel OWNER TO umrahfuras;

--
-- Name: visa; Type: TABLE; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE visa (
    "VisaNumber" bigint NOT NULL,
    "IssueDate" date,
    "ExpireDate" date,
    "Type" character varying,
    "MOFANumber" bigint,
    "PilgrimID" bigint,
    "VisaAttachment" text
);


ALTER TABLE pilgrim.visa OWNER TO umrahfuras;

SET search_path = sale_agent, pg_catalog;

--
-- Name: Agents_UID_seq; Type: SEQUENCE; Schema: sale_agent; Owner: umrahfuras
--

CREATE SEQUENCE "Agents_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sale_agent."Agents_UID_seq" OWNER TO umrahfuras;

--
-- Name: Agents; Type: TABLE; Schema: sale_agent; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Agents" (
    "UID" bigint DEFAULT nextval('"Agents_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "FullName" text,
    "PhoneNumber" character varying,
    "Email" character varying,
    "Password" character varying,
    "Country" character varying,
    "City" character varying,
    "Address" character varying,
    "Archive" smallint DEFAULT 0::smallint NOT NULL,
    "WebsiteDomain" bigint,
    "EmergencyContactNumber" character varying,
    "EmergencyContactName" text
);


ALTER TABLE sale_agent."Agents" OWNER TO umrahfuras;

--
-- Name: Meta_UID_seq; Type: SEQUENCE; Schema: sale_agent; Owner: umrahfuras
--

CREATE SEQUENCE "Meta_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sale_agent."Meta_UID_seq" OWNER TO umrahfuras;

--
-- Name: Meta; Type: TABLE; Schema: sale_agent; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Meta" (
    "UID" bigint DEFAULT nextval('"Meta_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "SaleAgentID" bigint,
    "Option" character varying,
    "Value" character varying
);


ALTER TABLE sale_agent."Meta" OWNER TO umrahfuras;

SET search_path = temp, pg_catalog;

--
-- Name: elm_file_UID_seq; Type: SEQUENCE; Schema: temp; Owner: umrahfuras
--

CREATE SEQUENCE "elm_file_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE temp."elm_file_UID_seq" OWNER TO umrahfuras;

--
-- Name: elm_file; Type: TABLE; Schema: temp; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE elm_file (
    "UID" bigint DEFAULT nextval('"elm_file_UID_seq"'::regclass) NOT NULL,
    "EACode" text,
    "EAName" text,
    "GroupCode" text,
    "GroupDesc" text,
    "PilgrimID" text,
    "Name" text,
    "BirthDate" text,
    "PassportNo" text,
    "MOINumber" text,
    "VisaNo" text,
    "EntryDate" text,
    "EntryTime" text,
    "EntryPort" text,
    "TransportMode" text,
    "EntryCarrier" text,
    "FlightNo" text,
    "Package" text
);


ALTER TABLE temp.elm_file OWNER TO umrahfuras;

--
-- Name: mofa_file_UID_seq; Type: SEQUENCE; Schema: temp; Owner: umrahfuras
--

CREATE SEQUENCE "mofa_file_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE temp."mofa_file_UID_seq" OWNER TO umrahfuras;

--
-- Name: mofa_file; Type: TABLE; Schema: temp; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE mofa_file (
    "UID" bigint DEFAULT nextval('"mofa_file_UID_seq"'::regclass) NOT NULL,
    "Operator" text,
    "ExtAgent" text,
    "Group" text,
    "PrintDate" text,
    "PilgrimName" text,
    "PilgrimID" text,
    "Age" text,
    "DOB" text,
    "GroupName" text,
    "PassportNo" text,
    "MOFANumber" text,
    "IssueDateTime" text,
    "Embassy" text,
    "PKGCode" text,
    "Relation" text,
    "Nationality" text,
    "Address" text,
    "SubAgentName" text,
    "MOINumber" text,
    "INSURANCE_POLICY_ID" text,
    "SystemDate" timestamp without time zone DEFAULT now()
);


ALTER TABLE temp.mofa_file OWNER TO umrahfuras;

SET search_path = uploads, pg_catalog;

--
-- Name: Files_UID_seq; Type: SEQUENCE; Schema: uploads; Owner: umrahfuras
--

CREATE SEQUENCE "Files_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE uploads."Files_UID_seq" OWNER TO umrahfuras;

--
-- Name: Files; Type: TABLE; Schema: uploads; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Files" (
    "UID" bigint DEFAULT nextval('"Files_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone,
    "Content" text,
    "Ext" character varying
);


ALTER TABLE uploads."Files" OWNER TO umrahfuras;

SET search_path = voucher, pg_catalog;

--
-- Name: AccommodationDetails_UID_seq; Type: SEQUENCE; Schema: voucher; Owner: umrahfuras
--

CREATE SEQUENCE "AccommodationDetails_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE voucher."AccommodationDetails_UID_seq" OWNER TO umrahfuras;

--
-- Name: AccommodationDetails; Type: TABLE; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "AccommodationDetails" (
    "UID" bigint DEFAULT nextval('"AccommodationDetails_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "VoucherID" bigint,
    "City" character varying,
    "Hotel" character varying,
    "RoomType" character varying,
    "CheckIn" date,
    "CheckOut" date,
    "NoOfBeds" character varying,
    "AmountPayable" character varying,
    "AccommodationBRN" character varying,
    "Self" smallint DEFAULT 0::smallint
);


ALTER TABLE voucher."AccommodationDetails" OWNER TO umrahfuras;

--
-- Name: Flights_UID_seq; Type: SEQUENCE; Schema: voucher; Owner: umrahfuras
--

CREATE SEQUENCE "Flights_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE voucher."Flights_UID_seq" OWNER TO umrahfuras;

--
-- Name: Flights; Type: TABLE; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Flights" (
    "UID" bigint DEFAULT nextval('"Flights_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "VoucherID" bigint,
    "FlightType" character varying,
    "SectorFrom" character varying,
    "PNR" character varying,
    "DepartureDate" date,
    "DepartureTime" time without time zone,
    "ArrivalDate" date,
    "ArrivalTime" time without time zone,
    "Airline" character varying,
    "SectorTo" character varying,
    "Reference" character varying,
    "TravelType" character varying,
    "TravelSelf" smallint DEFAULT 0::smallint
);


ALTER TABLE voucher."Flights" OWNER TO umrahfuras;

--
-- Name: Master_UID_seq; Type: SEQUENCE; Schema: voucher; Owner: umrahfuras
--

CREATE SEQUENCE "Master_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE voucher."Master_UID_seq" OWNER TO umrahfuras;

--
-- Name: Master; Type: TABLE; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Master" (
    "UID" bigint DEFAULT nextval('"Master_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "AgentUID" bigint,
    "VoucherCode" character varying,
    "ArrivalDate" date,
    "ReturnDate" date,
    "ArrivalType" character varying,
    "Reference" text,
    "Archive" smallint DEFAULT 0::smallint,
    "Country" character varying,
    "UpdationCounter" bigint DEFAULT 0::bigint NOT NULL,
    "WebsiteDomain" bigint,
    "CurrentStatus" character varying(255) DEFAULT 'Pending'::character varying NOT NULL,
    "CreatedBy" bigint,
    "CreatedDate" date,
    "ModifiedBy" bigint,
    "ModifiedDate" date
);


ALTER TABLE voucher."Master" OWNER TO umrahfuras;

--
-- Name: Pilgrim_UID_seq; Type: SEQUENCE; Schema: voucher; Owner: umrahfuras
--

CREATE SEQUENCE "Pilgrim_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE voucher."Pilgrim_UID_seq" OWNER TO umrahfuras;

--
-- Name: Pilgrim; Type: TABLE; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Pilgrim" (
    "UID" bigint DEFAULT nextval('"Pilgrim_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "VoucherUID" bigint,
    "PilgrimUID" bigint,
    "Leader" smallint DEFAULT 0::smallint NOT NULL
);


ALTER TABLE voucher."Pilgrim" OWNER TO umrahfuras;

--
-- Name: Remarks_UID_seq; Type: SEQUENCE; Schema: voucher; Owner: umrahfuras
--

CREATE SEQUENCE "Remarks_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE voucher."Remarks_UID_seq" OWNER TO umrahfuras;

--
-- Name: Remarks; Type: TABLE; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Remarks" (
    "UID" bigint DEFAULT nextval('"Remarks_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "VoucherID" bigint,
    "Remarks" text,
    "CreatedBy" bigint,
    "CreatedDate" timestamp without time zone
);


ALTER TABLE voucher."Remarks" OWNER TO umrahfuras;

--
-- Name: Services_UID_seq; Type: SEQUENCE; Schema: voucher; Owner: umrahfuras
--

CREATE SEQUENCE "Services_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE voucher."Services_UID_seq" OWNER TO umrahfuras;

--
-- Name: Services; Type: TABLE; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Services" (
    "UID" bigint DEFAULT nextval('"Services_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "VoucherUID" bigint,
    "ServiceID" character varying
);


ALTER TABLE voucher."Services" OWNER TO umrahfuras;

--
-- Name: TransportRate_UID_seq; Type: SEQUENCE; Schema: voucher; Owner: umrahfuras
--

CREATE SEQUENCE "TransportRate_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE voucher."TransportRate_UID_seq" OWNER TO umrahfuras;

--
-- Name: TransportRate; Type: TABLE; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "TransportRate" (
    "UID" bigint DEFAULT nextval('"TransportRate_UID_seq"'::regclass) NOT NULL,
    "VoucherUID" bigint,
    "TransportTypeUID" character varying,
    "Rate" character varying,
    "Sectors" bigint,
    "TransportsBRN" character varying,
    "NoOfPax" character varying,
    "NoOfSeats" character varying,
    "SelfTransport" smallint DEFAULT 0::smallint,
    "TravelDate" date,
    "TravelCity" bigint,
    "TravelType" character varying
);


ALTER TABLE voucher."TransportRate" OWNER TO umrahfuras;

--
-- Name: ZiyaratsRate_UID_seq; Type: SEQUENCE; Schema: voucher; Owner: umrahfuras
--

CREATE SEQUENCE "ZiyaratsRate_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE voucher."ZiyaratsRate_UID_seq" OWNER TO umrahfuras;

--
-- Name: ZiyaratsRate; Type: TABLE; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "ZiyaratsRate" (
    "UID" bigint DEFAULT nextval('"ZiyaratsRate_UID_seq"'::regclass) NOT NULL,
    "VoucherUID" bigint,
    "ZiyaratsUID" bigint,
    "Rate" double precision,
    "TransportTypeUID" character varying,
    "ZiyaratCity" character varying,
    "ZiyaratNoOfPax" bigint
);


ALTER TABLE voucher."ZiyaratsRate" OWNER TO umrahfuras;

SET search_path = websites, pg_catalog;

--
-- Name: domains_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "domains_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."domains_UID_seq" OWNER TO umrahfuras;

--
-- Name: Domains; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Domains" (
    "UID" bigint DEFAULT nextval('"domains_UID_seq"'::regclass) NOT NULL,
    "Name" character varying(255),
    "FullName" character varying(255),
    "Logo" text,
    "ParentID" bigint DEFAULT 0::bigint NOT NULL
);


ALTER TABLE websites."Domains" OWNER TO umrahfuras;

--
-- Name: Flight_Sectors_UID_seq; Type: SEQUENCE; Schema: websites; Owner: postgres
--

CREATE SEQUENCE "Flight_Sectors_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."Flight_Sectors_UID_seq" OWNER TO postgres;

--
-- Name: Flight_Sectors; Type: TABLE; Schema: websites; Owner: postgres; Tablespace: 
--

CREATE TABLE "Flight_Sectors" (
    "UID" bigint DEFAULT nextval('"Flight_Sectors_UID_seq"'::regclass) NOT NULL,
    "FlightID" bigint,
    "FlightType" character varying,
    "DepartureAirport" character varying,
    "DepartureAirportCode" character varying,
    "DepartureDate" date,
    "DepartureTime" time without time zone,
    "ArrivalAirport" character varying,
    "ArrivalAirportCode" character varying,
    "ArrivalDate" date,
    "ArrivalTime" time without time zone,
    "AirlineCode" character varying,
    "FlightDuration" character varying,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Archive" smallint DEFAULT 0
);


ALTER TABLE websites."Flight_Sectors" OWNER TO postgres;

--
-- Name: Order_Payment_UID_seq; Type: SEQUENCE; Schema: websites; Owner: postgres
--

CREATE SEQUENCE "Order_Payment_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."Order_Payment_UID_seq" OWNER TO postgres;

--
-- Name: Order_Payment; Type: TABLE; Schema: websites; Owner: postgres; Tablespace: 
--

CREATE TABLE "Order_Payment" (
    "UID" bigint DEFAULT nextval('"Order_Payment_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "OrderID" character varying,
    "PaymentMode" character varying,
    "Amount" character varying,
    "PaymentApiResponse" json,
    "Archive" smallint DEFAULT 0
);


ALTER TABLE websites."Order_Payment" OWNER TO postgres;

--
-- Name: Orders_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "Orders_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."Orders_UID_seq" OWNER TO umrahfuras;

--
-- Name: Orders; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Orders" (
    "UID" bigint DEFAULT nextval('"Orders_UID_seq"'::regclass) NOT NULL,
    "DomainID" bigint,
    "UserID" bigint,
    "Status" character varying,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "OrderDate" timestamp without time zone,
    "Amount" double precision NOT NULL
);


ALTER TABLE websites."Orders" OWNER TO umrahfuras;

--
-- Name: Orders_Flights_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "Orders_Flights_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."Orders_Flights_UID_seq" OWNER TO umrahfuras;

--
-- Name: Orders_Flights; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Orders_Flights" (
    "UID" bigint DEFAULT nextval('"Orders_Flights_UID_seq"'::regclass) NOT NULL,
    "OrderID" bigint,
    "DomainID" bigint,
    "FlightType" character varying,
    "FlightClass" character varying,
    "Adults" smallint,
    childs smallint DEFAULT 0,
    infants smallint DEFAULT 0,
    "Fare" character varying,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Archive" smallint DEFAULT 0
);


ALTER TABLE websites."Orders_Flights" OWNER TO umrahfuras;

--
-- Name: Orders_Hotel_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "Orders_Hotel_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."Orders_Hotel_UID_seq" OWNER TO umrahfuras;

--
-- Name: Orders_Hotel; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Orders_Hotel" (
    "UID" bigint DEFAULT nextval('"Orders_Hotel_UID_seq"'::regclass) NOT NULL,
    "OrderID" bigint,
    "DomainID" bigint,
    "City" character varying,
    "Hotel" character varying,
    "RoomType" character varying,
    "TotalRooms" bigint,
    "Rate" bigint,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Archive" smallint DEFAULT 0
);


ALTER TABLE websites."Orders_Hotel" OWNER TO umrahfuras;

--
-- Name: Orders_Transport_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "Orders_Transport_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."Orders_Transport_UID_seq" OWNER TO umrahfuras;

--
-- Name: Orders_Transport; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Orders_Transport" (
    "UID" bigint DEFAULT nextval('"Orders_Transport_UID_seq"'::regclass) NOT NULL,
    "OrderID" bigint,
    "DomainID" bigint,
    "TransportFor" character varying,
    "TransportName" character varying,
    "TransportType" character varying,
    "LuggageCapacity" character varying,
    "Sector" character varying,
    "Rate" bigint,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "Archive" smallint DEFAULT 0
);


ALTER TABLE websites."Orders_Transport" OWNER TO umrahfuras;

--
-- Name: Orders_Ziyarat_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "Orders_Ziyarat_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."Orders_Ziyarat_UID_seq" OWNER TO umrahfuras;

--
-- Name: Orders_Ziyarat; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Orders_Ziyarat" (
    "UID" bigint DEFAULT nextval('"Orders_Ziyarat_UID_seq"'::regclass) NOT NULL,
    "Order" bigint,
    "DomainID" bigint,
    "Ziyarat" character varying,
    "Transport" character varying,
    "Rate" character varying,
    "SystemDate" timestamp without time zone,
    "Archive" smallint DEFAULT 0
);


ALTER TABLE websites."Orders_Ziyarat" OWNER TO umrahfuras;

--
-- Name: Search_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "Search_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."Search_UID_seq" OWNER TO umrahfuras;

--
-- Name: Search; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Search" (
    "UID" bigint DEFAULT nextval('"Search_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "DomainID" bigint,
    "SearchType" character varying(50),
    "SearchRequest" json,
    "SearchResponse" json
);


ALTER TABLE websites."Search" OWNER TO umrahfuras;

--
-- Name: Settings; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE "Settings" (
    "DomainID" bigint DEFAULT 0::bigint,
    "Key" character varying(255),
    "Name" character varying(255),
    "Segment" character varying(255),
    "Description" text,
    "OrderNo" integer
);


ALTER TABLE websites."Settings" OWNER TO umrahfuras;

--
-- Name: contents_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "contents_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."contents_UID_seq" OWNER TO umrahfuras;

--
-- Name: contents; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE contents (
    "UID" bigint DEFAULT nextval('"contents_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "PagePhysical" character varying,
    "Title" character varying,
    "Description" text,
    "SeoTitle" character varying,
    "SeoMetaKeywords" character varying,
    "SeoDescription" character varying,
    "ShowOnFooter" smallint DEFAULT 0 NOT NULL,
    "Archive" smallint DEFAULT 0 NOT NULL,
    "DomainID" bigint DEFAULT 0::bigint NOT NULL,
    "Segment" smallint DEFAULT 0::smallint NOT NULL
);


ALTER TABLE websites.contents OWNER TO umrahfuras;

--
-- Name: contents_meta_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "contents_meta_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."contents_meta_UID_seq" OWNER TO umrahfuras;

--
-- Name: contents_meta; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE contents_meta (
    "UID" bigint DEFAULT nextval('"contents_meta_UID_seq"'::regclass) NOT NULL,
    "PagePhysical" character varying,
    "Key" character varying,
    "Description" text,
    "OrderID" smallint DEFAULT 0 NOT NULL,
    "DomainID" bigint DEFAULT 0::bigint NOT NULL,
    "Archive" smallint DEFAULT 0::smallint NOT NULL
);


ALTER TABLE websites.contents_meta OWNER TO umrahfuras;

--
-- Name: stats_UID_seq; Type: SEQUENCE; Schema: websites; Owner: umrahfuras
--

CREATE SEQUENCE "stats_UID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE websites."stats_UID_seq" OWNER TO umrahfuras;

--
-- Name: stats; Type: TABLE; Schema: websites; Owner: umrahfuras; Tablespace: 
--

CREATE TABLE stats (
    "UID" bigint DEFAULT nextval('"stats_UID_seq"'::regclass) NOT NULL,
    "SystemDate" timestamp without time zone DEFAULT now(),
    "DomainID" bigint DEFAULT 0::bigint,
    "StatsKey" character varying(255),
    "Value" character varying(240),
    "AgentID" bigint DEFAULT 0::bigint NOT NULL
);


ALTER TABLE websites.stats OWNER TO umrahfuras;

SET search_path = "BRN", pg_catalog;

--
-- Data for Name: UseBRN; Type: TABLE DATA; Schema: BRN; Owner: umrahfuras
--

COPY "UseBRN" ("UID", "SystemDate", "Type", "BRNCode", "Rooms", "Beds", "UseID", "UsedDate", "Seats", "Archive") FROM stdin;
\.
COPY "UseBRN" ("UID", "SystemDate", "Type", "BRNCode", "Rooms", "Beds", "UseID", "UsedDate", "Seats", "Archive") FROM '$$PATH$$/3778.dat';

--
-- Name: UseBRN_UID_seq; Type: SEQUENCE SET; Schema: BRN; Owner: umrahfuras
--

SELECT pg_catalog.setval('"UseBRN_UID_seq"', 1, false);


--
-- Data for Name: brn; Type: TABLE DATA; Schema: BRN; Owner: umrahfuras
--

COPY brn ("UID", "SystemDate", "BRNCode", "Operator", "Company", "Seats", "Beds", "Rooms", "GenerateDate", "ActiveDate", "ExpireDate", "WebsiteDomain", "Archive", "HotelsID", "BRNType", "CreatedBy", "CreatedDate", "ModifiedBy", "ModifiedDate", "PurchaseID", "PurchasedBy", "NoOfVehicles", "UseType", "BookingDate", "TransportType") FROM stdin;
\.
COPY brn ("UID", "SystemDate", "BRNCode", "Operator", "Company", "Seats", "Beds", "Rooms", "GenerateDate", "ActiveDate", "ExpireDate", "WebsiteDomain", "Archive", "HotelsID", "BRNType", "CreatedBy", "CreatedDate", "ModifiedBy", "ModifiedDate", "PurchaseID", "PurchasedBy", "NoOfVehicles", "UseType", "BookingDate", "TransportType") FROM '$$PATH$$/3768.dat';

--
-- Name: brn_UID_seq; Type: SEQUENCE SET; Schema: BRN; Owner: umrahfuras
--

SELECT pg_catalog.setval('"brn_UID_seq"', 565, true);


SET search_path = main, pg_catalog;

--
-- Data for Name: AccessLevel; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "AccessLevel" ("UID", "SystemDate", "UserID", "AccessKey", "Access") FROM stdin;
\.
COPY "AccessLevel" ("UID", "SystemDate", "UserID", "AccessKey", "Access") FROM '$$PATH$$/3696.dat';

--
-- Name: AccessLevel_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"AccessLevel_UID_seq"', 3135, true);


--
-- Data for Name: AdminLog; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "AdminLog" ("UID", "SystemDate", "LogSegment", "LogNotes", "LogIP") FROM stdin;
\.
COPY "AdminLog" ("UID", "SystemDate", "LogSegment", "LogNotes", "LogIP") FROM '$$PATH$$/3642.dat';

--
-- Name: AdminLog_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"AdminLog_UID_seq"', 3009, true);


--
-- Data for Name: AdminSettings; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "AdminSettings" ("Key", "Name", "Segment", "Description", "OrderNo", "DomainID") FROM stdin;
\.
COPY "AdminSettings" ("Key", "Name", "Segment", "Description", "OrderNo", "DomainID") FROM '$$PATH$$/3647.dat';

--
-- Data for Name: AgentFiles; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "AgentFiles" ("UID", "SystemDate", "AgentID", "FileDescription", "FileID") FROM stdin;
\.
COPY "AgentFiles" ("UID", "SystemDate", "AgentID", "FileDescription", "FileID") FROM '$$PATH$$/3708.dat';

--
-- Name: AgentFiles_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"AgentFiles_UID_seq"', 74, true);


--
-- Data for Name: Agents; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Agents" ("UID", "SystemDate", "FullName", "PhoneNumber", "Email", "Password", "Address", "Archive", "ParentID", "FaxNumber", "MobileNumber", "CityID", "CountryID", "ContactPersonName", "SalesmanID", "SalesmanName", "Status", "Logo", "IATALicense", "UmrahAgreement", "CompanyName", "WebsiteDomain", "Type", "LastName", "Domain") FROM stdin;
\.
COPY "Agents" ("UID", "SystemDate", "FullName", "PhoneNumber", "Email", "Password", "Address", "Archive", "ParentID", "FaxNumber", "MobileNumber", "CityID", "CountryID", "ContactPersonName", "SalesmanID", "SalesmanName", "Status", "Logo", "IATALicense", "UmrahAgreement", "CompanyName", "WebsiteDomain", "Type", "LastName", "Domain") FROM '$$PATH$$/3650.dat';

--
-- Name: Agents_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Agents_UID_seq"', 180, true);


--
-- Data for Name: Airlines; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Airlines" ("UID", "Code", "FullName", "CountryISO2", "Status", "Archive") FROM stdin;
\.
COPY "Airlines" ("UID", "Code", "FullName", "CountryISO2", "Status", "Archive") FROM '$$PATH$$/3730.dat';

--
-- Name: Airlines_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Airlines_UID_seq"', 5616, true);


--
-- Data for Name: Airports; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Airports" ("UID", "Name", "Code", "StateCode", "CountryCode", "CountryName") FROM stdin;
\.
COPY "Airports" ("UID", "Name", "Code", "StateCode", "CountryCode", "CountryName") FROM '$$PATH$$/3664.dat';

--
-- Name: Airports_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Airports_UID_seq"', 3741, true);


--
-- Data for Name: Cities; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Cities" ("UID", "Name", "StateUID", "StateCode", "CountryUID", "CountryCode", "Latitude", "Longitude", "Slug", "CoverImage") FROM stdin;
\.
COPY "Cities" ("UID", "Name", "StateUID", "StateCode", "CountryUID", "CountryCode", "Latitude", "Longitude", "Slug", "CoverImage") FROM '$$PATH$$/3666.dat';

--
-- Name: Cities_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Cities_UID_seq"', 287657, true);


--
-- Data for Name: Countries; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Countries" ("UID", "Name", "ISO2", "ISO3", "PhoneCode", "Capital", "Currency") FROM stdin;
\.
COPY "Countries" ("UID", "Name", "ISO2", "ISO3", "PhoneCode", "Capital", "Currency") FROM '$$PATH$$/3668.dat';

--
-- Name: Countries_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Countries_UID_seq"', 3783, true);


--
-- Data for Name: ExternalAgent; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "ExternalAgent" ("UID", "SystemDate", "FullName", "Archive", "DomainID") FROM stdin;
\.
COPY "ExternalAgent" ("UID", "SystemDate", "FullName", "Archive", "DomainID") FROM '$$PATH$$/3670.dat';

--
-- Name: ExternalAgent_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"ExternalAgent_UID_seq"', 2, true);


--
-- Data for Name: GroupHotel; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "GroupHotel" ("UID", "SystemDate", "GroupID", "City", "Hotel", "RoomType", "CheckIn", "CheckOut", "NoOfBeds", "AmountPayable") FROM stdin;
\.
COPY "GroupHotel" ("UID", "SystemDate", "GroupID", "City", "Hotel", "RoomType", "CheckIn", "CheckOut", "NoOfBeds", "AmountPayable") FROM '$$PATH$$/3770.dat';

--
-- Name: GroupHotel_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"GroupHotel_UID_seq"', 100, true);


--
-- Data for Name: GroupServices; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "GroupServices" ("UID", "SystemDate", "GroupID", "ServiceID", "ServiceRate") FROM stdin;
\.
COPY "GroupServices" ("UID", "SystemDate", "GroupID", "ServiceID", "ServiceRate") FROM '$$PATH$$/3776.dat';

--
-- Name: GroupServices_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"GroupServices_UID_seq"', 78, true);


--
-- Data for Name: GroupTransport; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "GroupTransport" ("UID", "SystemDate", "GroupID", "TransportSectors", "Transport", "NoOfPax", "NoOfSeats", "TransportsRates") FROM stdin;
\.
COPY "GroupTransport" ("UID", "SystemDate", "GroupID", "TransportSectors", "Transport", "NoOfPax", "NoOfSeats", "TransportsRates") FROM '$$PATH$$/3772.dat';

--
-- Name: GroupTransport_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"GroupTransport_UID_seq"', 53, true);


--
-- Data for Name: GroupZiyarat; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "GroupZiyarat" ("UID", "SystemDate", "GroupID", "ZiyaratCity", "Ziyarat", "TransportRateZiyrat", "ZiyaratTransport", "ZiyaratNoOfPax") FROM stdin;
\.
COPY "GroupZiyarat" ("UID", "SystemDate", "GroupID", "ZiyaratCity", "Ziyarat", "TransportRateZiyrat", "ZiyaratTransport", "ZiyaratNoOfPax") FROM '$$PATH$$/3774.dat';

--
-- Name: GroupZiyarat_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"GroupZiyarat_UID_seq"', 52, true);


--
-- Data for Name: Groups; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Groups" ("UID", "SystemDate", "FullName", "Archive", "AgentID", "WebsiteDomain", "Country", "WTUCode", "NoOfPAX", "TransportType", "ArrivalDate", "DepartureDate", "Remarks", "Status", "Visa") FROM stdin;
\.
COPY "Groups" ("UID", "SystemDate", "FullName", "Archive", "AgentID", "WebsiteDomain", "Country", "WTUCode", "NoOfPAX", "TransportType", "ArrivalDate", "DepartureDate", "Remarks", "Status", "Visa") FROM '$$PATH$$/3652.dat';

--
-- Name: Groups_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Groups_UID_seq"', 44, true);


--
-- Data for Name: Language; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Language" ("UID", "SystemDate", "Name", "Code", "DefaultFlag", "RTL") FROM stdin;
\.
COPY "Language" ("UID", "SystemDate", "Name", "Code", "DefaultFlag", "RTL") FROM '$$PATH$$/3672.dat';

--
-- Data for Name: LanguageTranslations; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "LanguageTranslations" ("UID", "Code", "Key", "Value") FROM stdin;
\.
COPY "LanguageTranslations" ("UID", "Code", "Key", "Value") FROM '$$PATH$$/3674.dat';

--
-- Name: LanguageTranslations_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"LanguageTranslations_UID_seq"', 14, true);


--
-- Name: Language_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Language_UID_seq"', 2, true);


--
-- Data for Name: Lookups; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Lookups" ("UID", "Key", "Name", "Description") FROM stdin;
\.
COPY "Lookups" ("UID", "Key", "Name", "Description") FROM '$$PATH$$/3656.dat';

--
-- Data for Name: LookupsOptions; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "LookupsOptions" ("UID", "LookupID", "Name", "OrderID", "Archive") FROM stdin;
\.
COPY "LookupsOptions" ("UID", "LookupID", "Name", "OrderID", "Archive") FROM '$$PATH$$/3658.dat';

--
-- Name: LookupsOptions_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"LookupsOptions_UID_seq"', 129, true);


--
-- Name: Lookups_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Lookups_UID_seq"', 16, true);


--
-- Data for Name: Operators; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Operators" ("UID", "SystemDate", "CompanyName", "Archive", "WebsiteDomain", "ContactPersonName", "ContactNo", "Email", "OfficeCity", "Category", "Country", "Type", "Logo") FROM stdin;
\.
COPY "Operators" ("UID", "SystemDate", "CompanyName", "Archive", "WebsiteDomain", "ContactPersonName", "ContactNo", "Email", "OfficeCity", "Category", "Country", "Type", "Logo") FROM '$$PATH$$/3646.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "Users" ("UID", "SystemDate", "FullName", "ContactNumber", "Email", "Password", "Designation", "UserType", "Archive", "AgentID", "DomainID") FROM stdin;
\.
COPY "Users" ("UID", "SystemDate", "FullName", "ContactNumber", "Email", "Password", "Designation", "UserType", "Archive", "AgentID", "DomainID") FROM '$$PATH$$/3654.dat';

--
-- Data for Name: UsersMeta; Type: TABLE DATA; Schema: main; Owner: umrahfuras
--

COPY "UsersMeta" ("UID", "UserUID", "Option", "Value") FROM stdin;
\.
COPY "UsersMeta" ("UID", "UserUID", "Option", "Value") FROM '$$PATH$$/3722.dat';

--
-- Name: UsersMeta_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"UsersMeta_UID_seq"', 51, true);


--
-- Name: Users_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Users_UID_seq"', 9, true);


--
-- Name: operators_UID_seq; Type: SEQUENCE SET; Schema: main; Owner: umrahfuras
--

SELECT pg_catalog.setval('"operators_UID_seq"', 6, true);


SET search_path = packages, pg_catalog;

--
-- Data for Name: HotelImage; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "HotelImage" ("UID", "HotelID", "ImageID") FROM stdin;
\.
COPY "HotelImage" ("UID", "HotelID", "ImageID") FROM '$$PATH$$/3694.dat';

--
-- Name: HotelImage_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"HotelImage_UID_seq"', 359, true);


--
-- Data for Name: Hotels; Type: TABLE DATA; Schema: packages; Owner: postgres
--

COPY "Hotels" ("UID", "SystemDate", "Name", "Category", "Distance", "Address", "TelephoneNumber", "Latitude", "Longitude", "GoogleMAP", "Archive", "CountryID", "CityID", "Description", "Status", "WebsiteDomain") FROM stdin;
\.
COPY "Hotels" ("UID", "SystemDate", "Name", "Category", "Distance", "Address", "TelephoneNumber", "Latitude", "Longitude", "GoogleMAP", "Archive", "CountryID", "CityID", "Description", "Status", "WebsiteDomain") FROM '$$PATH$$/3681.dat';

--
-- Data for Name: HotelsRate; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "HotelsRate" ("UID", "PackageUID", "HotelUID", "RoomTypeUID", "Rate", "RowID") FROM stdin;
\.
COPY "HotelsRate" ("UID", "PackageUID", "HotelUID", "RoomTypeUID", "Rate", "RowID") FROM '$$PATH$$/3688.dat';

--
-- Name: HotelsRate_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"HotelsRate_UID_seq"', 7966, true);


--
-- Name: Hotels_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Hotels_UID_seq"', 58, true);


--
-- Data for Name: Meta; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "Meta" ("UID", "ReferenceID", "ReferenceType", "Option", "Value") FROM stdin;
\.
COPY "Meta" ("UID", "ReferenceID", "ReferenceType", "Option", "Value") FROM '$$PATH$$/3702.dat';

--
-- Name: Meta_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Meta_UID_seq"', 1825, true);


--
-- Data for Name: OtherHotels; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "OtherHotels" ("UID", "SystemDate", "Name", "Category", "Distance", "Address", "TelephoneNumber", "Latitude", "Longitude", "GoogleMAP", "Archive", "CountryID", "CityID", "Description", "Status", "WebsiteDomain") FROM stdin;
\.
COPY "OtherHotels" ("UID", "SystemDate", "Name", "Category", "Distance", "Address", "TelephoneNumber", "Latitude", "Longitude", "GoogleMAP", "Archive", "CountryID", "CityID", "Description", "Status", "WebsiteDomain") FROM '$$PATH$$/3764.dat';

--
-- Name: OtherHotels_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"OtherHotels_UID_seq"', 6, true);


--
-- Data for Name: Packages; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "Packages" ("UID", "SystemDate", "Name", "StartDate", "ExpireDate", "Fee", "Archive", "CountryCode", "PackageType", "AgentUID", "ApprovalDate", "WebsiteDomain") FROM stdin;
\.
COPY "Packages" ("UID", "SystemDate", "Name", "StartDate", "ExpireDate", "Fee", "Archive", "CountryCode", "PackageType", "AgentUID", "ApprovalDate", "WebsiteDomain") FROM '$$PATH$$/3689.dat';

--
-- Name: Packages_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Packages_UID_seq"', 79, true);


--
-- Data for Name: ServiceRate; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "ServiceRate" ("UID", "SystemDate", "PackageUID", "ServiceUID", "Rate") FROM stdin;
\.
COPY "ServiceRate" ("UID", "SystemDate", "PackageUID", "ServiceUID", "Rate") FROM '$$PATH$$/3710.dat';

--
-- Name: ServiceRate_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"ServiceRate_UID_seq"', 770, true);


--
-- Data for Name: Transport; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "Transport" ("UID", "SystemDate", "Type", "LuggageCapacity", "Description", "Archive", "PAXDetail", "CoverImage", "WebsiteDomain") FROM stdin;
\.
COPY "Transport" ("UID", "SystemDate", "Type", "LuggageCapacity", "Description", "Archive", "PAXDetail", "CoverImage", "WebsiteDomain") FROM '$$PATH$$/3678.dat';

--
-- Data for Name: TransportImage; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "TransportImage" ("UID", "TransportID", "FileID") FROM stdin;
\.
COPY "TransportImage" ("UID", "TransportID", "FileID") FROM '$$PATH$$/3692.dat';

--
-- Name: TransportImage_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"TransportImage_UID_seq"', 53, true);


--
-- Data for Name: TransportRate; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "TransportRate" ("UID", "PackageUID", "TransportTypeUID", "Rate", "RowID", "Routes") FROM stdin;
\.
COPY "TransportRate" ("UID", "PackageUID", "TransportTypeUID", "Rate", "RowID", "Routes") FROM '$$PATH$$/3690.dat';

--
-- Name: TransportRate_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"TransportRate_UID_seq"', 15161, true);


--
-- Name: Transport_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Transport_UID_seq"', 14, true);


--
-- Data for Name: Ziyarats; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "Ziyarats" ("UID", "SystemDate", "Name", "CountryID", "CityID", "CoverImage", "Description", "NearPlaces", "Archive", "WebsiteDomain") FROM stdin;
\.
COPY "Ziyarats" ("UID", "SystemDate", "Name", "CountryID", "CityID", "CoverImage", "Description", "NearPlaces", "Archive", "WebsiteDomain") FROM '$$PATH$$/3698.dat';

--
-- Data for Name: ZiyaratsRate; Type: TABLE DATA; Schema: packages; Owner: umrahfuras
--

COPY "ZiyaratsRate" ("UID", "PackageUID", "ZiyaratsUID", "Rate", "RowID", "TransportTypeUID") FROM stdin;
\.
COPY "ZiyaratsRate" ("UID", "PackageUID", "ZiyaratsUID", "Rate", "RowID", "TransportTypeUID") FROM '$$PATH$$/3701.dat';

--
-- Name: ZiyaratsRate_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"ZiyaratsRate_UID_seq"', 2775, true);


--
-- Name: Ziyarats_UID_seq; Type: SEQUENCE SET; Schema: packages; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Ziyarats_UID_seq"', 57, true);


SET search_path = pilgrim, pg_catalog;

--
-- Data for Name: activities; Type: TABLE DATA; Schema: pilgrim; Owner: umrahfuras
--

COPY activities ("UID", "SystemDate", "UserID", "PilgrimUID", "Activity", "ActivityDescription", "IPAddress") FROM stdin;
\.
COPY activities ("UID", "SystemDate", "UserID", "PilgrimUID", "Activity", "ActivityDescription", "IPAddress") FROM '$$PATH$$/3728.dat';

--
-- Name: activities_UID_seq; Type: SEQUENCE SET; Schema: pilgrim; Owner: umrahfuras
--

SELECT pg_catalog.setval('"activities_UID_seq"', 7679, true);


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: pilgrim; Owner: umrahfuras
--

COPY attachments ("UID", "SystemDate", "PilgrimID", "FileDescription", "FileID") FROM stdin;
\.
COPY attachments ("UID", "SystemDate", "PilgrimID", "FileDescription", "FileID") FROM '$$PATH$$/3724.dat';

--
-- Name: attachments_UID_seq; Type: SEQUENCE SET; Schema: pilgrim; Owner: umrahfuras
--

SELECT pg_catalog.setval('"attachments_UID_seq"', 22, true);


--
-- Data for Name: auth; Type: TABLE DATA; Schema: pilgrim; Owner: umrahfuras
--

COPY auth ("UID", "SystemDate", "DomainID", "PilgrimID", "Email", "Password", "LastLoginDateTime", "LastLoginIPAddress", "Status") FROM stdin;
\.
COPY auth ("UID", "SystemDate", "DomainID", "PilgrimID", "Email", "Password", "LastLoginDateTime", "LastLoginIPAddress", "Status") FROM '$$PATH$$/3726.dat';

--
-- Name: auth_UID_seq; Type: SEQUENCE SET; Schema: pilgrim; Owner: umrahfuras
--

SELECT pg_catalog.setval('"auth_UID_seq"', 16, true);


--
-- Data for Name: master; Type: TABLE DATA; Schema: pilgrim; Owner: umrahfuras
--

COPY master ("UID", "AgentUID", "GroupUID", "Title", "FirstName", "LastName", "Relation", "Profile", "RegistrationDate", "Country", "DOB", "DOBInYears", "PassportNumber", "Nationality", "CurrentStatus", "ContactNumber", "Email", "Password", "CityID", "ParentID", "WebsiteDomain", "Gender") FROM stdin;
\.
COPY master ("UID", "AgentUID", "GroupUID", "Title", "FirstName", "LastName", "Relation", "Profile", "RegistrationDate", "Country", "DOB", "DOBInYears", "PassportNumber", "Nationality", "CurrentStatus", "ContactNumber", "Email", "Password", "CityID", "ParentID", "WebsiteDomain", "Gender") FROM '$$PATH$$/3660.dat';

--
-- Name: master_UID_seq; Type: SEQUENCE SET; Schema: pilgrim; Owner: umrahfuras
--

SELECT pg_catalog.setval('"master_UID_seq"', 9259, true);


--
-- Data for Name: meta; Type: TABLE DATA; Schema: pilgrim; Owner: umrahfuras
--

COPY meta ("UID", "PilgrimUID", "Option", "Value", "SystemDate", "CreatedBy", "AllowReference") FROM stdin;
\.
COPY meta ("UID", "PilgrimUID", "Option", "Value", "SystemDate", "CreatedBy", "AllowReference") FROM '$$PATH$$/3662.dat';

--
-- Name: meta_UID_seq; Type: SEQUENCE SET; Schema: pilgrim; Owner: umrahfuras
--

SELECT pg_catalog.setval('"meta_UID_seq"', 78612, true);


--
-- Data for Name: mofa; Type: TABLE DATA; Schema: pilgrim; Owner: umrahfuras
--

COPY mofa ("MOFANumber", "MOFAPilgrimID", "IssueDateTime", "MOINumber", "INSURANCE_POLICY_ID", "PilgrimID", "Embassy") FROM stdin;
\.
COPY mofa ("MOFANumber", "MOFAPilgrimID", "IssueDateTime", "MOINumber", "INSURANCE_POLICY_ID", "PilgrimID", "Embassy") FROM '$$PATH$$/3680.dat';

--
-- Data for Name: passport; Type: TABLE DATA; Schema: pilgrim; Owner: umrahfuras
--

COPY passport ("UID", "SystemDate", "PilgrimID", "PassportNumber", "PassportType", "Nationality", "DateOfIssue", "DateOfExpiry", "TrackingNumber", "CitizenshipNumber", "BookletNumber", "File") FROM stdin;
\.
COPY passport ("UID", "SystemDate", "PilgrimID", "PassportNumber", "PassportType", "Nationality", "DateOfIssue", "DateOfExpiry", "TrackingNumber", "CitizenshipNumber", "BookletNumber", "File") FROM '$$PATH$$/3712.dat';

--
-- Name: passport_UID_seq; Type: SEQUENCE SET; Schema: pilgrim; Owner: umrahfuras
--

SELECT pg_catalog.setval('"passport_UID_seq"', 898, true);


--
-- Data for Name: travel; Type: TABLE DATA; Schema: pilgrim; Owner: umrahfuras
--

COPY travel ("UID", "PilgrimID", "MOFAPilgrimID", "PassportNo", "MOINumber", "VisaNo", "EntryDate", "EntryTime", "EntryPort", "TransportMode", "EntryCarrier", "FlightNo") FROM stdin;
\.
COPY travel ("UID", "PilgrimID", "MOFAPilgrimID", "PassportNo", "MOINumber", "VisaNo", "EntryDate", "EntryTime", "EntryPort", "TransportMode", "EntryCarrier", "FlightNo") FROM '$$PATH$$/3716.dat';

--
-- Name: travel_UID_seq; Type: SEQUENCE SET; Schema: pilgrim; Owner: umrahfuras
--

SELECT pg_catalog.setval('"travel_UID_seq"', 1478, true);


--
-- Data for Name: visa; Type: TABLE DATA; Schema: pilgrim; Owner: umrahfuras
--

COPY visa ("VisaNumber", "IssueDate", "ExpireDate", "Type", "MOFANumber", "PilgrimID", "VisaAttachment") FROM stdin;
\.
COPY visa ("VisaNumber", "IssueDate", "ExpireDate", "Type", "MOFANumber", "PilgrimID", "VisaAttachment") FROM '$$PATH$$/3682.dat';

SET search_path = sale_agent, pg_catalog;

--
-- Data for Name: Agents; Type: TABLE DATA; Schema: sale_agent; Owner: umrahfuras
--

COPY "Agents" ("UID", "SystemDate", "FullName", "PhoneNumber", "Email", "Password", "Country", "City", "Address", "Archive", "WebsiteDomain", "EmergencyContactNumber", "EmergencyContactName") FROM stdin;
\.
COPY "Agents" ("UID", "SystemDate", "FullName", "PhoneNumber", "Email", "Password", "Country", "City", "Address", "Archive", "WebsiteDomain", "EmergencyContactNumber", "EmergencyContactName") FROM '$$PATH$$/3734.dat';

--
-- Name: Agents_UID_seq; Type: SEQUENCE SET; Schema: sale_agent; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Agents_UID_seq"', 11, true);


--
-- Data for Name: Meta; Type: TABLE DATA; Schema: sale_agent; Owner: umrahfuras
--

COPY "Meta" ("UID", "SystemDate", "SaleAgentID", "Option", "Value") FROM stdin;
\.
COPY "Meta" ("UID", "SystemDate", "SaleAgentID", "Option", "Value") FROM '$$PATH$$/3736.dat';

--
-- Name: Meta_UID_seq; Type: SEQUENCE SET; Schema: sale_agent; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Meta_UID_seq"', 123, true);


SET search_path = temp, pg_catalog;

--
-- Data for Name: elm_file; Type: TABLE DATA; Schema: temp; Owner: umrahfuras
--

COPY elm_file ("UID", "EACode", "EAName", "GroupCode", "GroupDesc", "PilgrimID", "Name", "BirthDate", "PassportNo", "MOINumber", "VisaNo", "EntryDate", "EntryTime", "EntryPort", "TransportMode", "EntryCarrier", "FlightNo", "Package") FROM stdin;
\.
COPY elm_file ("UID", "EACode", "EAName", "GroupCode", "GroupDesc", "PilgrimID", "Name", "BirthDate", "PassportNo", "MOINumber", "VisaNo", "EntryDate", "EntryTime", "EntryPort", "TransportMode", "EntryCarrier", "FlightNo", "Package") FROM '$$PATH$$/3714.dat';

--
-- Name: elm_file_UID_seq; Type: SEQUENCE SET; Schema: temp; Owner: umrahfuras
--

SELECT pg_catalog.setval('"elm_file_UID_seq"', 447, true);


--
-- Data for Name: mofa_file; Type: TABLE DATA; Schema: temp; Owner: umrahfuras
--

COPY mofa_file ("UID", "Operator", "ExtAgent", "Group", "PrintDate", "PilgrimName", "PilgrimID", "Age", "DOB", "GroupName", "PassportNo", "MOFANumber", "IssueDateTime", "Embassy", "PKGCode", "Relation", "Nationality", "Address", "SubAgentName", "MOINumber", "INSURANCE_POLICY_ID", "SystemDate") FROM stdin;
\.
COPY mofa_file ("UID", "Operator", "ExtAgent", "Group", "PrintDate", "PilgrimName", "PilgrimID", "Age", "DOB", "GroupName", "PassportNo", "MOFANumber", "IssueDateTime", "Embassy", "PKGCode", "Relation", "Nationality", "Address", "SubAgentName", "MOINumber", "INSURANCE_POLICY_ID", "SystemDate") FROM '$$PATH$$/3676.dat';

--
-- Name: mofa_file_UID_seq; Type: SEQUENCE SET; Schema: temp; Owner: umrahfuras
--

SELECT pg_catalog.setval('"mofa_file_UID_seq"', 12190, true);


SET search_path = uploads, pg_catalog;

--
-- Data for Name: Files; Type: TABLE DATA; Schema: uploads; Owner: umrahfuras
--

COPY "Files" ("UID", "SystemDate", "Content", "Ext") FROM stdin;
\.
COPY "Files" ("UID", "SystemDate", "Content", "Ext") FROM '$$PATH$$/3684.dat';

--
-- Name: Files_UID_seq; Type: SEQUENCE SET; Schema: uploads; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Files_UID_seq"', 1040, true);


SET search_path = voucher, pg_catalog;

--
-- Data for Name: AccommodationDetails; Type: TABLE DATA; Schema: voucher; Owner: umrahfuras
--

COPY "AccommodationDetails" ("UID", "SystemDate", "VoucherID", "City", "Hotel", "RoomType", "CheckIn", "CheckOut", "NoOfBeds", "AmountPayable", "AccommodationBRN", "Self") FROM stdin;
\.
COPY "AccommodationDetails" ("UID", "SystemDate", "VoucherID", "City", "Hotel", "RoomType", "CheckIn", "CheckOut", "NoOfBeds", "AmountPayable", "AccommodationBRN", "Self") FROM '$$PATH$$/3740.dat';

--
-- Name: AccommodationDetails_UID_seq; Type: SEQUENCE SET; Schema: voucher; Owner: umrahfuras
--

SELECT pg_catalog.setval('"AccommodationDetails_UID_seq"', 806, true);


--
-- Data for Name: Flights; Type: TABLE DATA; Schema: voucher; Owner: umrahfuras
--

COPY "Flights" ("UID", "SystemDate", "VoucherID", "FlightType", "SectorFrom", "PNR", "DepartureDate", "DepartureTime", "ArrivalDate", "ArrivalTime", "Airline", "SectorTo", "Reference", "TravelType", "TravelSelf") FROM stdin;
\.
COPY "Flights" ("UID", "SystemDate", "VoucherID", "FlightType", "SectorFrom", "PNR", "DepartureDate", "DepartureTime", "ArrivalDate", "ArrivalTime", "Airline", "SectorTo", "Reference", "TravelType", "TravelSelf") FROM '$$PATH$$/3738.dat';

--
-- Name: Flights_UID_seq; Type: SEQUENCE SET; Schema: voucher; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Flights_UID_seq"', 609, true);


--
-- Data for Name: Master; Type: TABLE DATA; Schema: voucher; Owner: umrahfuras
--

COPY "Master" ("UID", "SystemDate", "AgentUID", "VoucherCode", "ArrivalDate", "ReturnDate", "ArrivalType", "Reference", "Archive", "Country", "UpdationCounter", "WebsiteDomain", "CurrentStatus", "CreatedBy", "CreatedDate", "ModifiedBy", "ModifiedDate") FROM stdin;
\.
COPY "Master" ("UID", "SystemDate", "AgentUID", "VoucherCode", "ArrivalDate", "ReturnDate", "ArrivalType", "Reference", "Archive", "Country", "UpdationCounter", "WebsiteDomain", "CurrentStatus", "CreatedBy", "CreatedDate", "ModifiedBy", "ModifiedDate") FROM '$$PATH$$/3704.dat';

--
-- Name: Master_UID_seq; Type: SEQUENCE SET; Schema: voucher; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Master_UID_seq"', 158, true);


--
-- Data for Name: Pilgrim; Type: TABLE DATA; Schema: voucher; Owner: umrahfuras
--

COPY "Pilgrim" ("UID", "SystemDate", "VoucherUID", "PilgrimUID", "Leader") FROM stdin;
\.
COPY "Pilgrim" ("UID", "SystemDate", "VoucherUID", "PilgrimUID", "Leader") FROM '$$PATH$$/3706.dat';

--
-- Name: Pilgrim_UID_seq; Type: SEQUENCE SET; Schema: voucher; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Pilgrim_UID_seq"', 4804, true);


--
-- Data for Name: Remarks; Type: TABLE DATA; Schema: voucher; Owner: umrahfuras
--

COPY "Remarks" ("UID", "SystemDate", "VoucherID", "Remarks", "CreatedBy", "CreatedDate") FROM stdin;
\.
COPY "Remarks" ("UID", "SystemDate", "VoucherID", "Remarks", "CreatedBy", "CreatedDate") FROM '$$PATH$$/3766.dat';

--
-- Name: Remarks_UID_seq; Type: SEQUENCE SET; Schema: voucher; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Remarks_UID_seq"', 469, true);


--
-- Data for Name: Services; Type: TABLE DATA; Schema: voucher; Owner: umrahfuras
--

COPY "Services" ("UID", "SystemDate", "VoucherUID", "ServiceID") FROM stdin;
\.
COPY "Services" ("UID", "SystemDate", "VoucherUID", "ServiceID") FROM '$$PATH$$/3754.dat';

--
-- Name: Services_UID_seq; Type: SEQUENCE SET; Schema: voucher; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Services_UID_seq"', 1146, true);


--
-- Data for Name: TransportRate; Type: TABLE DATA; Schema: voucher; Owner: umrahfuras
--

COPY "TransportRate" ("UID", "VoucherUID", "TransportTypeUID", "Rate", "Sectors", "TransportsBRN", "NoOfPax", "NoOfSeats", "SelfTransport", "TravelDate", "TravelCity", "TravelType") FROM stdin;
\.
COPY "TransportRate" ("UID", "VoucherUID", "TransportTypeUID", "Rate", "Sectors", "TransportsBRN", "NoOfPax", "NoOfSeats", "SelfTransport", "TravelDate", "TravelCity", "TravelType") FROM '$$PATH$$/3742.dat';

--
-- Name: TransportRate_UID_seq; Type: SEQUENCE SET; Schema: voucher; Owner: umrahfuras
--

SELECT pg_catalog.setval('"TransportRate_UID_seq"', 524, true);


--
-- Data for Name: ZiyaratsRate; Type: TABLE DATA; Schema: voucher; Owner: umrahfuras
--

COPY "ZiyaratsRate" ("UID", "VoucherUID", "ZiyaratsUID", "Rate", "TransportTypeUID", "ZiyaratCity", "ZiyaratNoOfPax") FROM stdin;
\.
COPY "ZiyaratsRate" ("UID", "VoucherUID", "ZiyaratsUID", "Rate", "TransportTypeUID", "ZiyaratCity", "ZiyaratNoOfPax") FROM '$$PATH$$/3744.dat';

--
-- Name: ZiyaratsRate_UID_seq; Type: SEQUENCE SET; Schema: voucher; Owner: umrahfuras
--

SELECT pg_catalog.setval('"ZiyaratsRate_UID_seq"', 356, true);


SET search_path = websites, pg_catalog;

--
-- Data for Name: Domains; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY "Domains" ("UID", "Name", "FullName", "Logo", "ParentID") FROM stdin;
\.
COPY "Domains" ("UID", "Name", "FullName", "Logo", "ParentID") FROM '$$PATH$$/3644.dat';

--
-- Data for Name: Flight_Sectors; Type: TABLE DATA; Schema: websites; Owner: postgres
--

COPY "Flight_Sectors" ("UID", "FlightID", "FlightType", "DepartureAirport", "DepartureAirportCode", "DepartureDate", "DepartureTime", "ArrivalAirport", "ArrivalAirportCode", "ArrivalDate", "ArrivalTime", "AirlineCode", "FlightDuration", "SystemDate", "Archive") FROM stdin;
\.
COPY "Flight_Sectors" ("UID", "FlightID", "FlightType", "DepartureAirport", "DepartureAirportCode", "DepartureDate", "DepartureTime", "ArrivalAirport", "ArrivalAirportCode", "ArrivalDate", "ArrivalTime", "AirlineCode", "FlightDuration", "SystemDate", "Archive") FROM '$$PATH$$/3750.dat';

--
-- Name: Flight_Sectors_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: postgres
--

SELECT pg_catalog.setval('"Flight_Sectors_UID_seq"', 12, true);


--
-- Data for Name: Order_Payment; Type: TABLE DATA; Schema: websites; Owner: postgres
--

COPY "Order_Payment" ("UID", "SystemDate", "OrderID", "PaymentMode", "Amount", "PaymentApiResponse", "Archive") FROM stdin;
\.
COPY "Order_Payment" ("UID", "SystemDate", "OrderID", "PaymentMode", "Amount", "PaymentApiResponse", "Archive") FROM '$$PATH$$/3752.dat';

--
-- Name: Order_Payment_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: postgres
--

SELECT pg_catalog.setval('"Order_Payment_UID_seq"', 2, true);


--
-- Data for Name: Orders; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY "Orders" ("UID", "DomainID", "UserID", "Status", "SystemDate", "OrderDate", "Amount") FROM stdin;
\.
COPY "Orders" ("UID", "DomainID", "UserID", "Status", "SystemDate", "OrderDate", "Amount") FROM '$$PATH$$/3746.dat';

--
-- Data for Name: Orders_Flights; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY "Orders_Flights" ("UID", "OrderID", "DomainID", "FlightType", "FlightClass", "Adults", childs, infants, "Fare", "SystemDate", "Archive") FROM stdin;
\.
COPY "Orders_Flights" ("UID", "OrderID", "DomainID", "FlightType", "FlightClass", "Adults", childs, infants, "Fare", "SystemDate", "Archive") FROM '$$PATH$$/3748.dat';

--
-- Name: Orders_Flights_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Orders_Flights_UID_seq"', 6, true);


--
-- Data for Name: Orders_Hotel; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY "Orders_Hotel" ("UID", "OrderID", "DomainID", "City", "Hotel", "RoomType", "TotalRooms", "Rate", "SystemDate", "Archive") FROM stdin;
\.
COPY "Orders_Hotel" ("UID", "OrderID", "DomainID", "City", "Hotel", "RoomType", "TotalRooms", "Rate", "SystemDate", "Archive") FROM '$$PATH$$/3758.dat';

--
-- Name: Orders_Hotel_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Orders_Hotel_UID_seq"', 2, true);


--
-- Data for Name: Orders_Transport; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY "Orders_Transport" ("UID", "OrderID", "DomainID", "TransportFor", "TransportName", "TransportType", "LuggageCapacity", "Sector", "Rate", "SystemDate", "Archive") FROM stdin;
\.
COPY "Orders_Transport" ("UID", "OrderID", "DomainID", "TransportFor", "TransportName", "TransportType", "LuggageCapacity", "Sector", "Rate", "SystemDate", "Archive") FROM '$$PATH$$/3760.dat';

--
-- Name: Orders_Transport_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Orders_Transport_UID_seq"', 2, true);


--
-- Name: Orders_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Orders_UID_seq"', 6, true);


--
-- Data for Name: Orders_Ziyarat; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY "Orders_Ziyarat" ("UID", "Order", "DomainID", "Ziyarat", "Transport", "Rate", "SystemDate", "Archive") FROM stdin;
\.
COPY "Orders_Ziyarat" ("UID", "Order", "DomainID", "Ziyarat", "Transport", "Rate", "SystemDate", "Archive") FROM '$$PATH$$/3756.dat';

--
-- Name: Orders_Ziyarat_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Orders_Ziyarat_UID_seq"', 1, false);


--
-- Data for Name: Search; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY "Search" ("UID", "SystemDate", "DomainID", "SearchType", "SearchRequest", "SearchResponse") FROM stdin;
\.
COPY "Search" ("UID", "SystemDate", "DomainID", "SearchType", "SearchRequest", "SearchResponse") FROM '$$PATH$$/3732.dat';

--
-- Name: Search_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"Search_UID_seq"', 102, true);


--
-- Data for Name: Settings; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY "Settings" ("DomainID", "Key", "Name", "Segment", "Description", "OrderNo") FROM stdin;
\.
COPY "Settings" ("DomainID", "Key", "Name", "Segment", "Description", "OrderNo") FROM '$$PATH$$/3648.dat';

--
-- Data for Name: contents; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY contents ("UID", "SystemDate", "PagePhysical", "Title", "Description", "SeoTitle", "SeoMetaKeywords", "SeoDescription", "ShowOnFooter", "Archive", "DomainID", "Segment") FROM stdin;
\.
COPY contents ("UID", "SystemDate", "PagePhysical", "Title", "Description", "SeoTitle", "SeoMetaKeywords", "SeoDescription", "ShowOnFooter", "Archive", "DomainID", "Segment") FROM '$$PATH$$/3718.dat';

--
-- Name: contents_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"contents_UID_seq"', 7, true);


--
-- Data for Name: contents_meta; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY contents_meta ("UID", "PagePhysical", "Key", "Description", "OrderID", "DomainID", "Archive") FROM stdin;
\.
COPY contents_meta ("UID", "PagePhysical", "Key", "Description", "OrderID", "DomainID", "Archive") FROM '$$PATH$$/3720.dat';

--
-- Name: contents_meta_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"contents_meta_UID_seq"', 63, true);


--
-- Name: domains_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"domains_UID_seq"', 6, true);


--
-- Data for Name: stats; Type: TABLE DATA; Schema: websites; Owner: umrahfuras
--

COPY stats ("UID", "SystemDate", "DomainID", "StatsKey", "Value", "AgentID") FROM stdin;
\.
COPY stats ("UID", "SystemDate", "DomainID", "StatsKey", "Value", "AgentID") FROM '$$PATH$$/3762.dat';

--
-- Name: stats_UID_seq; Type: SEQUENCE SET; Schema: websites; Owner: umrahfuras
--

SELECT pg_catalog.setval('"stats_UID_seq"', 8613483, true);


SET search_path = "BRN", pg_catalog;

--
-- Name: UseBRN_pkey; Type: CONSTRAINT; Schema: BRN; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "UseBRN"
    ADD CONSTRAINT "UseBRN_pkey" PRIMARY KEY ("UID");


--
-- Name: brn_pkey; Type: CONSTRAINT; Schema: BRN; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY brn
    ADD CONSTRAINT brn_pkey PRIMARY KEY ("UID");


SET search_path = main, pg_catalog;

--
-- Name: AccessLevel_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "AccessLevel"
    ADD CONSTRAINT "AccessLevel_pkey" PRIMARY KEY ("UID");


--
-- Name: AdminLog_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "AdminLog"
    ADD CONSTRAINT "AdminLog_pkey" PRIMARY KEY ("UID");


--
-- Name: AdminSettings_Key_DomainID; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "AdminSettings"
    ADD CONSTRAINT "AdminSettings_Key_DomainID" UNIQUE ("Key", "DomainID");


--
-- Name: AgentImages_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "AgentFiles"
    ADD CONSTRAINT "AgentImages_pkey" PRIMARY KEY ("UID");


--
-- Name: Agents_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Agents"
    ADD CONSTRAINT "Agents_pkey" PRIMARY KEY ("UID");


--
-- Name: Airlines_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Airlines"
    ADD CONSTRAINT "Airlines_pkey" PRIMARY KEY ("UID");


--
-- Name: Airports_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Airports"
    ADD CONSTRAINT "Airports_pkey" PRIMARY KEY ("UID");


--
-- Name: Cities_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Cities"
    ADD CONSTRAINT "Cities_pkey" PRIMARY KEY ("UID");


--
-- Name: Code_Key; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "LanguageTranslations"
    ADD CONSTRAINT "Code_Key" UNIQUE ("Code", "Key");


--
-- Name: Countries_ISO2; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Countries"
    ADD CONSTRAINT "Countries_ISO2" UNIQUE ("ISO2");


--
-- Name: Countries_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Countries"
    ADD CONSTRAINT "Countries_pkey" PRIMARY KEY ("UID");


--
-- Name: ExternalAgent_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "ExternalAgent"
    ADD CONSTRAINT "ExternalAgent_pkey" PRIMARY KEY ("UID");


--
-- Name: GroupHotel_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "GroupHotel"
    ADD CONSTRAINT "GroupHotel_pkey" PRIMARY KEY ("UID");


--
-- Name: GroupServices_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "GroupServices"
    ADD CONSTRAINT "GroupServices_pkey" PRIMARY KEY ("UID");


--
-- Name: GroupTransport_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "GroupTransport"
    ADD CONSTRAINT "GroupTransport_pkey" PRIMARY KEY ("UID");


--
-- Name: GroupZiyarat_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "GroupZiyarat"
    ADD CONSTRAINT "GroupZiyarat_pkey" PRIMARY KEY ("UID");


--
-- Name: Groups_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Groups"
    ADD CONSTRAINT "Groups_pkey" PRIMARY KEY ("UID");


--
-- Name: KeyDuplicate; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Lookups"
    ADD CONSTRAINT "KeyDuplicate" UNIQUE ("Key");


--
-- Name: LanguageTranslations_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "LanguageTranslations"
    ADD CONSTRAINT "LanguageTranslations_pkey" PRIMARY KEY ("UID");


--
-- Name: Language_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Language"
    ADD CONSTRAINT "Language_pkey" PRIMARY KEY ("UID");


--
-- Name: LookupsOptions_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "LookupsOptions"
    ADD CONSTRAINT "LookupsOptions_pkey" PRIMARY KEY ("UID");


--
-- Name: Lookups_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Lookups"
    ADD CONSTRAINT "Lookups_pkey" PRIMARY KEY ("UID");


--
-- Name: UsersMeta_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "UsersMeta"
    ADD CONSTRAINT "UsersMeta_pkey" PRIMARY KEY ("UID");


--
-- Name: Users_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY ("UID");


--
-- Name: operators_pkey; Type: CONSTRAINT; Schema: main; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Operators"
    ADD CONSTRAINT operators_pkey PRIMARY KEY ("UID");


SET search_path = packages, pg_catalog;

--
-- Name: HotelImage_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "HotelImage"
    ADD CONSTRAINT "HotelImage_pkey" PRIMARY KEY ("UID");


--
-- Name: HotelsRate_pkey1; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "HotelsRate"
    ADD CONSTRAINT "HotelsRate_pkey1" PRIMARY KEY ("UID");


--
-- Name: Hotels_pkey; Type: CONSTRAINT; Schema: packages; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Hotels"
    ADD CONSTRAINT "Hotels_pkey" PRIMARY KEY ("UID");


--
-- Name: Meta_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Meta"
    ADD CONSTRAINT "Meta_pkey" PRIMARY KEY ("UID");


--
-- Name: OtherHotels_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "OtherHotels"
    ADD CONSTRAINT "OtherHotels_pkey" PRIMARY KEY ("UID");


--
-- Name: Packages_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Packages"
    ADD CONSTRAINT "Packages_pkey" PRIMARY KEY ("UID");


--
-- Name: ServiceRate_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "ServiceRate"
    ADD CONSTRAINT "ServiceRate_pkey" PRIMARY KEY ("UID");


--
-- Name: TransportImage_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "TransportImage"
    ADD CONSTRAINT "TransportImage_pkey" PRIMARY KEY ("UID");


--
-- Name: TransportRate_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "TransportRate"
    ADD CONSTRAINT "TransportRate_pkey" PRIMARY KEY ("UID");


--
-- Name: Transport_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Transport"
    ADD CONSTRAINT "Transport_pkey" PRIMARY KEY ("UID");


--
-- Name: ZiyaratsRate_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "ZiyaratsRate"
    ADD CONSTRAINT "ZiyaratsRate_pkey" PRIMARY KEY ("UID");


--
-- Name: Ziyarats_pkey; Type: CONSTRAINT; Schema: packages; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Ziyarats"
    ADD CONSTRAINT "Ziyarats_pkey" PRIMARY KEY ("UID");


SET search_path = pilgrim, pg_catalog;

--
-- Name: activities_pkey; Type: CONSTRAINT; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY ("UID");


--
-- Name: attachments_pkey; Type: CONSTRAINT; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY ("UID");


--
-- Name: auth_pkey; Type: CONSTRAINT; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY ("UID");


--
-- Name: master_pkey; Type: CONSTRAINT; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY master
    ADD CONSTRAINT master_pkey PRIMARY KEY ("UID");


--
-- Name: meta_pkey; Type: CONSTRAINT; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY meta
    ADD CONSTRAINT meta_pkey PRIMARY KEY ("UID");


--
-- Name: passport_pkey; Type: CONSTRAINT; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY passport
    ADD CONSTRAINT passport_pkey PRIMARY KEY ("UID");


--
-- Name: travel_pkey; Type: CONSTRAINT; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY travel
    ADD CONSTRAINT travel_pkey PRIMARY KEY ("UID");


--
-- Name: visa_pkey; Type: CONSTRAINT; Schema: pilgrim; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY visa
    ADD CONSTRAINT visa_pkey PRIMARY KEY ("VisaNumber");


SET search_path = sale_agent, pg_catalog;

--
-- Name: Agents_pkey; Type: CONSTRAINT; Schema: sale_agent; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Agents"
    ADD CONSTRAINT "Agents_pkey" PRIMARY KEY ("UID");


--
-- Name: Meta_pkey; Type: CONSTRAINT; Schema: sale_agent; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Meta"
    ADD CONSTRAINT "Meta_pkey" PRIMARY KEY ("UID");


SET search_path = temp, pg_catalog;

--
-- Name: Passport; Type: CONSTRAINT; Schema: temp; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY elm_file
    ADD CONSTRAINT "Passport" UNIQUE ("PassportNo");


--
-- Name: elm_file_pkey; Type: CONSTRAINT; Schema: temp; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY elm_file
    ADD CONSTRAINT elm_file_pkey PRIMARY KEY ("UID");


--
-- Name: mofaID; Type: CONSTRAINT; Schema: temp; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY mofa_file
    ADD CONSTRAINT "mofaID" UNIQUE ("MOFANumber");


--
-- Name: mofa_file_pkey; Type: CONSTRAINT; Schema: temp; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY mofa_file
    ADD CONSTRAINT mofa_file_pkey PRIMARY KEY ("UID");


SET search_path = uploads, pg_catalog;

--
-- Name: Files_pkey; Type: CONSTRAINT; Schema: uploads; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Files"
    ADD CONSTRAINT "Files_pkey" PRIMARY KEY ("UID");


SET search_path = voucher, pg_catalog;

--
-- Name: AccommodationDetails_pkey; Type: CONSTRAINT; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "AccommodationDetails"
    ADD CONSTRAINT "AccommodationDetails_pkey" PRIMARY KEY ("UID");


--
-- Name: Flights_pkey; Type: CONSTRAINT; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Flights"
    ADD CONSTRAINT "Flights_pkey" PRIMARY KEY ("UID");


--
-- Name: Master_pkey; Type: CONSTRAINT; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Master"
    ADD CONSTRAINT "Master_pkey" PRIMARY KEY ("UID");


--
-- Name: Pilgrim_pkey; Type: CONSTRAINT; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Pilgrim"
    ADD CONSTRAINT "Pilgrim_pkey" PRIMARY KEY ("UID");


--
-- Name: Remarks_pkey; Type: CONSTRAINT; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Remarks"
    ADD CONSTRAINT "Remarks_pkey" PRIMARY KEY ("UID");


--
-- Name: Services_pkey; Type: CONSTRAINT; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Services"
    ADD CONSTRAINT "Services_pkey" PRIMARY KEY ("UID");


--
-- Name: TransportRate_pkey; Type: CONSTRAINT; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "TransportRate"
    ADD CONSTRAINT "TransportRate_pkey" PRIMARY KEY ("UID");


--
-- Name: ZiyaratsRate_pkey; Type: CONSTRAINT; Schema: voucher; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "ZiyaratsRate"
    ADD CONSTRAINT "ZiyaratsRate_pkey" PRIMARY KEY ("UID");


SET search_path = websites, pg_catalog;

--
-- Name: Flight_Sectors_pkey; Type: CONSTRAINT; Schema: websites; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Flight_Sectors"
    ADD CONSTRAINT "Flight_Sectors_pkey" PRIMARY KEY ("UID");


--
-- Name: Order_Payment_pkey; Type: CONSTRAINT; Schema: websites; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Order_Payment"
    ADD CONSTRAINT "Order_Payment_pkey" PRIMARY KEY ("UID");


--
-- Name: Orders_Flights_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Orders_Flights"
    ADD CONSTRAINT "Orders_Flights_pkey" PRIMARY KEY ("UID");


--
-- Name: Orders_Hotel_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Orders_Hotel"
    ADD CONSTRAINT "Orders_Hotel_pkey" PRIMARY KEY ("UID");


--
-- Name: Orders_Transport_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Orders_Transport"
    ADD CONSTRAINT "Orders_Transport_pkey" PRIMARY KEY ("UID");


--
-- Name: Orders_Ziyarat_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Orders_Ziyarat"
    ADD CONSTRAINT "Orders_Ziyarat_pkey" PRIMARY KEY ("UID");


--
-- Name: Orders_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Orders"
    ADD CONSTRAINT "Orders_pkey" PRIMARY KEY ("UID");


--
-- Name: Search_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Search"
    ADD CONSTRAINT "Search_pkey" PRIMARY KEY ("UID");


--
-- Name: Settings_Key_DomainID; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Settings"
    ADD CONSTRAINT "Settings_Key_DomainID" UNIQUE ("Key", "DomainID");


--
-- Name: contents_meta_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY contents_meta
    ADD CONSTRAINT contents_meta_pkey PRIMARY KEY ("UID");


--
-- Name: contents_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY contents
    ADD CONSTRAINT contents_pkey PRIMARY KEY ("UID");


--
-- Name: domains_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY "Domains"
    ADD CONSTRAINT domains_pkey PRIMARY KEY ("UID");


--
-- Name: stats_pkey; Type: CONSTRAINT; Schema: websites; Owner: umrahfuras; Tablespace: 
--

ALTER TABLE ONLY stats
    ADD CONSTRAINT stats_pkey PRIMARY KEY ("UID");


--
-- Name: public; Type: ACL; Schema: -; Owner: umrahfuras
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM umrahfuras;
GRANT ALL ON SCHEMA public TO umrahfuras;
GRANT ALL ON SCHEMA public TO PUBLIC;


SET search_path = "BRN", pg_catalog;

--
-- Name: UseBRN; Type: ACL; Schema: BRN; Owner: umrahfuras
--

REVOKE ALL ON TABLE "UseBRN" FROM PUBLIC;
REVOKE ALL ON TABLE "UseBRN" FROM umrahfuras;
GRANT ALL ON TABLE "UseBRN" TO umrahfuras;
GRANT ALL ON TABLE "UseBRN" TO umrahfuras_maindb;


--
-- Name: brn; Type: ACL; Schema: BRN; Owner: umrahfuras
--

REVOKE ALL ON TABLE brn FROM PUBLIC;
REVOKE ALL ON TABLE brn FROM umrahfuras;
GRANT ALL ON TABLE brn TO umrahfuras;
GRANT ALL ON TABLE brn TO umrahfuras_maindb;


SET search_path = main, pg_catalog;

--
-- Name: AccessLevel; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "AccessLevel" FROM PUBLIC;
REVOKE ALL ON TABLE "AccessLevel" FROM umrahfuras;
GRANT ALL ON TABLE "AccessLevel" TO umrahfuras;
GRANT ALL ON TABLE "AccessLevel" TO umrahfuras_maindb;


--
-- Name: AdminLog; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "AdminLog" FROM PUBLIC;
REVOKE ALL ON TABLE "AdminLog" FROM umrahfuras;
GRANT ALL ON TABLE "AdminLog" TO umrahfuras;
GRANT ALL ON TABLE "AdminLog" TO umrahfuras_maindb;


--
-- Name: AdminSettings; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "AdminSettings" FROM PUBLIC;
REVOKE ALL ON TABLE "AdminSettings" FROM umrahfuras;
GRANT ALL ON TABLE "AdminSettings" TO umrahfuras;
GRANT ALL ON TABLE "AdminSettings" TO umrahfuras_maindb;


--
-- Name: AgentFiles; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "AgentFiles" FROM PUBLIC;
REVOKE ALL ON TABLE "AgentFiles" FROM umrahfuras;
GRANT ALL ON TABLE "AgentFiles" TO umrahfuras;
GRANT ALL ON TABLE "AgentFiles" TO umrahfuras_maindb;


--
-- Name: Agents; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Agents" FROM PUBLIC;
REVOKE ALL ON TABLE "Agents" FROM umrahfuras;
GRANT ALL ON TABLE "Agents" TO umrahfuras;
GRANT ALL ON TABLE "Agents" TO umrahfuras_maindb;


--
-- Name: Airlines; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Airlines" FROM PUBLIC;
REVOKE ALL ON TABLE "Airlines" FROM umrahfuras;
GRANT ALL ON TABLE "Airlines" TO umrahfuras;
GRANT ALL ON TABLE "Airlines" TO umrahfuras_maindb;


--
-- Name: Airports; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Airports" FROM PUBLIC;
REVOKE ALL ON TABLE "Airports" FROM umrahfuras;
GRANT ALL ON TABLE "Airports" TO umrahfuras;
GRANT ALL ON TABLE "Airports" TO umrahfuras_maindb;


--
-- Name: Cities; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Cities" FROM PUBLIC;
REVOKE ALL ON TABLE "Cities" FROM umrahfuras;
GRANT ALL ON TABLE "Cities" TO umrahfuras;
GRANT ALL ON TABLE "Cities" TO umrahfuras_maindb;


--
-- Name: Countries; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Countries" FROM PUBLIC;
REVOKE ALL ON TABLE "Countries" FROM umrahfuras;
GRANT ALL ON TABLE "Countries" TO umrahfuras;
GRANT ALL ON TABLE "Countries" TO umrahfuras_maindb;


--
-- Name: ExternalAgent; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "ExternalAgent" FROM PUBLIC;
REVOKE ALL ON TABLE "ExternalAgent" FROM umrahfuras;
GRANT ALL ON TABLE "ExternalAgent" TO umrahfuras;
GRANT ALL ON TABLE "ExternalAgent" TO umrahfuras_maindb;


--
-- Name: GroupHotel; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "GroupHotel" FROM PUBLIC;
REVOKE ALL ON TABLE "GroupHotel" FROM umrahfuras;
GRANT ALL ON TABLE "GroupHotel" TO umrahfuras;
GRANT ALL ON TABLE "GroupHotel" TO umrahfuras_maindb;


--
-- Name: GroupServices; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "GroupServices" FROM PUBLIC;
REVOKE ALL ON TABLE "GroupServices" FROM umrahfuras;
GRANT ALL ON TABLE "GroupServices" TO umrahfuras;
GRANT ALL ON TABLE "GroupServices" TO umrahfuras_maindb;


--
-- Name: GroupTransport; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "GroupTransport" FROM PUBLIC;
REVOKE ALL ON TABLE "GroupTransport" FROM umrahfuras;
GRANT ALL ON TABLE "GroupTransport" TO umrahfuras;
GRANT ALL ON TABLE "GroupTransport" TO umrahfuras_maindb;


--
-- Name: GroupZiyarat; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "GroupZiyarat" FROM PUBLIC;
REVOKE ALL ON TABLE "GroupZiyarat" FROM umrahfuras;
GRANT ALL ON TABLE "GroupZiyarat" TO umrahfuras;
GRANT ALL ON TABLE "GroupZiyarat" TO umrahfuras_maindb;


--
-- Name: Groups; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Groups" FROM PUBLIC;
REVOKE ALL ON TABLE "Groups" FROM umrahfuras;
GRANT ALL ON TABLE "Groups" TO umrahfuras;
GRANT ALL ON TABLE "Groups" TO umrahfuras_maindb;


--
-- Name: Language; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Language" FROM PUBLIC;
REVOKE ALL ON TABLE "Language" FROM umrahfuras;
GRANT ALL ON TABLE "Language" TO umrahfuras;
GRANT ALL ON TABLE "Language" TO umrahfuras_maindb;


--
-- Name: LanguageTranslations; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "LanguageTranslations" FROM PUBLIC;
REVOKE ALL ON TABLE "LanguageTranslations" FROM umrahfuras;
GRANT ALL ON TABLE "LanguageTranslations" TO umrahfuras;
GRANT ALL ON TABLE "LanguageTranslations" TO umrahfuras_maindb;


--
-- Name: Lookups; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Lookups" FROM PUBLIC;
REVOKE ALL ON TABLE "Lookups" FROM umrahfuras;
GRANT ALL ON TABLE "Lookups" TO umrahfuras;
GRANT ALL ON TABLE "Lookups" TO umrahfuras_maindb;


--
-- Name: LookupsOptions; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "LookupsOptions" FROM PUBLIC;
REVOKE ALL ON TABLE "LookupsOptions" FROM umrahfuras;
GRANT ALL ON TABLE "LookupsOptions" TO umrahfuras;
GRANT ALL ON TABLE "LookupsOptions" TO umrahfuras_maindb;


--
-- Name: Operators; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Operators" FROM PUBLIC;
REVOKE ALL ON TABLE "Operators" FROM umrahfuras;
GRANT ALL ON TABLE "Operators" TO umrahfuras;
GRANT ALL ON TABLE "Operators" TO umrahfuras_maindb;


--
-- Name: Users; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Users" FROM PUBLIC;
REVOKE ALL ON TABLE "Users" FROM umrahfuras;
GRANT ALL ON TABLE "Users" TO umrahfuras;
GRANT ALL ON TABLE "Users" TO umrahfuras_maindb;


--
-- Name: UsersMeta; Type: ACL; Schema: main; Owner: umrahfuras
--

REVOKE ALL ON TABLE "UsersMeta" FROM PUBLIC;
REVOKE ALL ON TABLE "UsersMeta" FROM umrahfuras;
GRANT ALL ON TABLE "UsersMeta" TO umrahfuras;
GRANT ALL ON TABLE "UsersMeta" TO umrahfuras_maindb;


SET search_path = packages, pg_catalog;

--
-- Name: HotelImage; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "HotelImage" FROM PUBLIC;
REVOKE ALL ON TABLE "HotelImage" FROM umrahfuras;
GRANT ALL ON TABLE "HotelImage" TO umrahfuras;
GRANT ALL ON TABLE "HotelImage" TO umrahfuras_maindb;


--
-- Name: HotelsRate; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "HotelsRate" FROM PUBLIC;
REVOKE ALL ON TABLE "HotelsRate" FROM umrahfuras;
GRANT ALL ON TABLE "HotelsRate" TO umrahfuras;
GRANT ALL ON TABLE "HotelsRate" TO umrahfuras_maindb;


--
-- Name: Meta; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Meta" FROM PUBLIC;
REVOKE ALL ON TABLE "Meta" FROM umrahfuras;
GRANT ALL ON TABLE "Meta" TO umrahfuras;
GRANT ALL ON TABLE "Meta" TO umrahfuras_maindb;


--
-- Name: OtherHotels; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "OtherHotels" FROM PUBLIC;
REVOKE ALL ON TABLE "OtherHotels" FROM umrahfuras;
GRANT ALL ON TABLE "OtherHotels" TO umrahfuras;
GRANT ALL ON TABLE "OtherHotels" TO umrahfuras_maindb;


--
-- Name: Packages; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Packages" FROM PUBLIC;
REVOKE ALL ON TABLE "Packages" FROM umrahfuras;
GRANT ALL ON TABLE "Packages" TO umrahfuras;
GRANT ALL ON TABLE "Packages" TO umrahfuras_maindb;


--
-- Name: ServiceRate; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "ServiceRate" FROM PUBLIC;
REVOKE ALL ON TABLE "ServiceRate" FROM umrahfuras;
GRANT ALL ON TABLE "ServiceRate" TO umrahfuras;
GRANT ALL ON TABLE "ServiceRate" TO umrahfuras_maindb;


--
-- Name: Transport; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Transport" FROM PUBLIC;
REVOKE ALL ON TABLE "Transport" FROM umrahfuras;
GRANT ALL ON TABLE "Transport" TO umrahfuras;
GRANT ALL ON TABLE "Transport" TO umrahfuras_maindb;


--
-- Name: TransportImage; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "TransportImage" FROM PUBLIC;
REVOKE ALL ON TABLE "TransportImage" FROM umrahfuras;
GRANT ALL ON TABLE "TransportImage" TO umrahfuras;
GRANT ALL ON TABLE "TransportImage" TO umrahfuras_maindb;


--
-- Name: TransportRate; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "TransportRate" FROM PUBLIC;
REVOKE ALL ON TABLE "TransportRate" FROM umrahfuras;
GRANT ALL ON TABLE "TransportRate" TO umrahfuras;
GRANT ALL ON TABLE "TransportRate" TO umrahfuras_maindb;


--
-- Name: Ziyarats; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Ziyarats" FROM PUBLIC;
REVOKE ALL ON TABLE "Ziyarats" FROM umrahfuras;
GRANT ALL ON TABLE "Ziyarats" TO umrahfuras;
GRANT ALL ON TABLE "Ziyarats" TO umrahfuras_maindb;


--
-- Name: ZiyaratsRate; Type: ACL; Schema: packages; Owner: umrahfuras
--

REVOKE ALL ON TABLE "ZiyaratsRate" FROM PUBLIC;
REVOKE ALL ON TABLE "ZiyaratsRate" FROM umrahfuras;
GRANT ALL ON TABLE "ZiyaratsRate" TO umrahfuras;
GRANT ALL ON TABLE "ZiyaratsRate" TO umrahfuras_maindb;


SET search_path = pilgrim, pg_catalog;

--
-- Name: activities; Type: ACL; Schema: pilgrim; Owner: umrahfuras
--

REVOKE ALL ON TABLE activities FROM PUBLIC;
REVOKE ALL ON TABLE activities FROM umrahfuras;
GRANT ALL ON TABLE activities TO umrahfuras;
GRANT ALL ON TABLE activities TO umrahfuras_maindb;


--
-- Name: attachments; Type: ACL; Schema: pilgrim; Owner: umrahfuras
--

REVOKE ALL ON TABLE attachments FROM PUBLIC;
REVOKE ALL ON TABLE attachments FROM umrahfuras;
GRANT ALL ON TABLE attachments TO umrahfuras;
GRANT ALL ON TABLE attachments TO umrahfuras_maindb;


--
-- Name: auth; Type: ACL; Schema: pilgrim; Owner: umrahfuras
--

REVOKE ALL ON TABLE auth FROM PUBLIC;
REVOKE ALL ON TABLE auth FROM umrahfuras;
GRANT ALL ON TABLE auth TO umrahfuras;
GRANT ALL ON TABLE auth TO umrahfuras_maindb;


--
-- Name: master; Type: ACL; Schema: pilgrim; Owner: umrahfuras
--

REVOKE ALL ON TABLE master FROM PUBLIC;
REVOKE ALL ON TABLE master FROM umrahfuras;
GRANT ALL ON TABLE master TO umrahfuras;
GRANT ALL ON TABLE master TO umrahfuras_maindb;


--
-- Name: meta; Type: ACL; Schema: pilgrim; Owner: umrahfuras
--

REVOKE ALL ON TABLE meta FROM PUBLIC;
REVOKE ALL ON TABLE meta FROM umrahfuras;
GRANT ALL ON TABLE meta TO umrahfuras;
GRANT ALL ON TABLE meta TO umrahfuras_maindb;


--
-- Name: mofa; Type: ACL; Schema: pilgrim; Owner: umrahfuras
--

REVOKE ALL ON TABLE mofa FROM PUBLIC;
REVOKE ALL ON TABLE mofa FROM umrahfuras;
GRANT ALL ON TABLE mofa TO umrahfuras;
GRANT ALL ON TABLE mofa TO umrahfuras_maindb;


--
-- Name: passport; Type: ACL; Schema: pilgrim; Owner: umrahfuras
--

REVOKE ALL ON TABLE passport FROM PUBLIC;
REVOKE ALL ON TABLE passport FROM umrahfuras;
GRANT ALL ON TABLE passport TO umrahfuras;
GRANT ALL ON TABLE passport TO umrahfuras_maindb;


--
-- Name: travel; Type: ACL; Schema: pilgrim; Owner: umrahfuras
--

REVOKE ALL ON TABLE travel FROM PUBLIC;
REVOKE ALL ON TABLE travel FROM umrahfuras;
GRANT ALL ON TABLE travel TO umrahfuras;
GRANT ALL ON TABLE travel TO umrahfuras_maindb;


--
-- Name: visa; Type: ACL; Schema: pilgrim; Owner: umrahfuras
--

REVOKE ALL ON TABLE visa FROM PUBLIC;
REVOKE ALL ON TABLE visa FROM umrahfuras;
GRANT ALL ON TABLE visa TO umrahfuras;
GRANT ALL ON TABLE visa TO umrahfuras_maindb;


SET search_path = sale_agent, pg_catalog;

--
-- Name: Agents; Type: ACL; Schema: sale_agent; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Agents" FROM PUBLIC;
REVOKE ALL ON TABLE "Agents" FROM umrahfuras;
GRANT ALL ON TABLE "Agents" TO umrahfuras;
GRANT ALL ON TABLE "Agents" TO umrahfuras_maindb;


--
-- Name: Meta; Type: ACL; Schema: sale_agent; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Meta" FROM PUBLIC;
REVOKE ALL ON TABLE "Meta" FROM umrahfuras;
GRANT ALL ON TABLE "Meta" TO umrahfuras;
GRANT ALL ON TABLE "Meta" TO umrahfuras_maindb;


SET search_path = temp, pg_catalog;

--
-- Name: elm_file; Type: ACL; Schema: temp; Owner: umrahfuras
--

REVOKE ALL ON TABLE elm_file FROM PUBLIC;
REVOKE ALL ON TABLE elm_file FROM umrahfuras;
GRANT ALL ON TABLE elm_file TO umrahfuras;
GRANT ALL ON TABLE elm_file TO umrahfuras_maindb;


--
-- Name: mofa_file; Type: ACL; Schema: temp; Owner: umrahfuras
--

REVOKE ALL ON TABLE mofa_file FROM PUBLIC;
REVOKE ALL ON TABLE mofa_file FROM umrahfuras;
GRANT ALL ON TABLE mofa_file TO umrahfuras;
GRANT ALL ON TABLE mofa_file TO umrahfuras_maindb;


SET search_path = uploads, pg_catalog;

--
-- Name: Files; Type: ACL; Schema: uploads; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Files" FROM PUBLIC;
REVOKE ALL ON TABLE "Files" FROM umrahfuras;
GRANT ALL ON TABLE "Files" TO umrahfuras;
GRANT ALL ON TABLE "Files" TO umrahfuras_maindb;


SET search_path = voucher, pg_catalog;

--
-- Name: AccommodationDetails; Type: ACL; Schema: voucher; Owner: umrahfuras
--

REVOKE ALL ON TABLE "AccommodationDetails" FROM PUBLIC;
REVOKE ALL ON TABLE "AccommodationDetails" FROM umrahfuras;
GRANT ALL ON TABLE "AccommodationDetails" TO umrahfuras;
GRANT ALL ON TABLE "AccommodationDetails" TO umrahfuras_maindb;


--
-- Name: Flights; Type: ACL; Schema: voucher; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Flights" FROM PUBLIC;
REVOKE ALL ON TABLE "Flights" FROM umrahfuras;
GRANT ALL ON TABLE "Flights" TO umrahfuras;
GRANT ALL ON TABLE "Flights" TO umrahfuras_maindb;


--
-- Name: Master; Type: ACL; Schema: voucher; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Master" FROM PUBLIC;
REVOKE ALL ON TABLE "Master" FROM umrahfuras;
GRANT ALL ON TABLE "Master" TO umrahfuras;
GRANT ALL ON TABLE "Master" TO umrahfuras_maindb;


--
-- Name: Pilgrim; Type: ACL; Schema: voucher; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Pilgrim" FROM PUBLIC;
REVOKE ALL ON TABLE "Pilgrim" FROM umrahfuras;
GRANT ALL ON TABLE "Pilgrim" TO umrahfuras;
GRANT ALL ON TABLE "Pilgrim" TO umrahfuras_maindb;


--
-- Name: Remarks; Type: ACL; Schema: voucher; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Remarks" FROM PUBLIC;
REVOKE ALL ON TABLE "Remarks" FROM umrahfuras;
GRANT ALL ON TABLE "Remarks" TO umrahfuras;
GRANT ALL ON TABLE "Remarks" TO umrahfuras_maindb;


--
-- Name: Services; Type: ACL; Schema: voucher; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Services" FROM PUBLIC;
REVOKE ALL ON TABLE "Services" FROM umrahfuras;
GRANT ALL ON TABLE "Services" TO umrahfuras;
GRANT ALL ON TABLE "Services" TO umrahfuras_maindb;


--
-- Name: TransportRate; Type: ACL; Schema: voucher; Owner: umrahfuras
--

REVOKE ALL ON TABLE "TransportRate" FROM PUBLIC;
REVOKE ALL ON TABLE "TransportRate" FROM umrahfuras;
GRANT ALL ON TABLE "TransportRate" TO umrahfuras;
GRANT ALL ON TABLE "TransportRate" TO umrahfuras_maindb;


--
-- Name: ZiyaratsRate; Type: ACL; Schema: voucher; Owner: umrahfuras
--

REVOKE ALL ON TABLE "ZiyaratsRate" FROM PUBLIC;
REVOKE ALL ON TABLE "ZiyaratsRate" FROM umrahfuras;
GRANT ALL ON TABLE "ZiyaratsRate" TO umrahfuras;
GRANT ALL ON TABLE "ZiyaratsRate" TO umrahfuras_maindb;


SET search_path = websites, pg_catalog;

--
-- Name: Domains; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Domains" FROM PUBLIC;
REVOKE ALL ON TABLE "Domains" FROM umrahfuras;
GRANT ALL ON TABLE "Domains" TO umrahfuras;
GRANT ALL ON TABLE "Domains" TO umrahfuras_maindb;


--
-- Name: Orders; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Orders" FROM PUBLIC;
REVOKE ALL ON TABLE "Orders" FROM umrahfuras;
GRANT ALL ON TABLE "Orders" TO umrahfuras;
GRANT ALL ON TABLE "Orders" TO umrahfuras_maindb;


--
-- Name: Orders_Flights; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Orders_Flights" FROM PUBLIC;
REVOKE ALL ON TABLE "Orders_Flights" FROM umrahfuras;
GRANT ALL ON TABLE "Orders_Flights" TO umrahfuras;
GRANT ALL ON TABLE "Orders_Flights" TO umrahfuras_maindb;


--
-- Name: Orders_Hotel; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Orders_Hotel" FROM PUBLIC;
REVOKE ALL ON TABLE "Orders_Hotel" FROM umrahfuras;
GRANT ALL ON TABLE "Orders_Hotel" TO umrahfuras;
GRANT ALL ON TABLE "Orders_Hotel" TO umrahfuras_maindb;


--
-- Name: Orders_Transport; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Orders_Transport" FROM PUBLIC;
REVOKE ALL ON TABLE "Orders_Transport" FROM umrahfuras;
GRANT ALL ON TABLE "Orders_Transport" TO umrahfuras;
GRANT ALL ON TABLE "Orders_Transport" TO umrahfuras_maindb;


--
-- Name: Orders_Ziyarat; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Orders_Ziyarat" FROM PUBLIC;
REVOKE ALL ON TABLE "Orders_Ziyarat" FROM umrahfuras;
GRANT ALL ON TABLE "Orders_Ziyarat" TO umrahfuras;
GRANT ALL ON TABLE "Orders_Ziyarat" TO umrahfuras_maindb;


--
-- Name: Search; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Search" FROM PUBLIC;
REVOKE ALL ON TABLE "Search" FROM umrahfuras;
GRANT ALL ON TABLE "Search" TO umrahfuras;
GRANT ALL ON TABLE "Search" TO umrahfuras_maindb;


--
-- Name: Settings; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE "Settings" FROM PUBLIC;
REVOKE ALL ON TABLE "Settings" FROM umrahfuras;
GRANT ALL ON TABLE "Settings" TO umrahfuras;
GRANT ALL ON TABLE "Settings" TO umrahfuras_maindb;


--
-- Name: contents; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE contents FROM PUBLIC;
REVOKE ALL ON TABLE contents FROM umrahfuras;
GRANT ALL ON TABLE contents TO umrahfuras;
GRANT ALL ON TABLE contents TO umrahfuras_maindb;


--
-- Name: contents_meta; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE contents_meta FROM PUBLIC;
REVOKE ALL ON TABLE contents_meta FROM umrahfuras;
GRANT ALL ON TABLE contents_meta TO umrahfuras;
GRANT ALL ON TABLE contents_meta TO umrahfuras_maindb;


--
-- Name: stats; Type: ACL; Schema: websites; Owner: umrahfuras
--

REVOKE ALL ON TABLE stats FROM PUBLIC;
REVOKE ALL ON TABLE stats FROM umrahfuras;
GRANT ALL ON TABLE stats TO umrahfuras;
GRANT ALL ON TABLE stats TO umrahfuras_maindb;


--
-- PostgreSQL database dump complete
--

